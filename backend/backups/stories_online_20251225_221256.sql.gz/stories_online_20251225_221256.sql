--
-- PostgreSQL database dump
--

\restrict lsGxJN36EWHlpduPHO5dyUMwTdyV7p6rRHF2raAgtSripzI82TK2NwgIXdBacvR

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: enforce_character_faction_same_adventure(); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.enforce_character_faction_same_adventure() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    c_adv BIGINT;
    f_adv BIGINT;
BEGIN
    SELECT adventure_id INTO c_adv FROM adventures_character WHERE id = NEW.character_id;
    SELECT adventure_id INTO f_adv FROM adventures_faction   WHERE id = NEW.faction_id;

    IF c_adv IS NULL OR f_adv IS NULL THEN
        RAISE EXCEPTION 'Character % or faction % not found', NEW.character_id, NEW.faction_id;
    END IF;

    IF NEW.adventure_id <> c_adv OR NEW.adventure_id <> f_adv THEN
        RAISE EXCEPTION 'Adventure mismatch in characters_factions: row adv %, char adv %, faction adv %',
            NEW.adventure_id, c_adv, f_adv;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.enforce_character_faction_same_adventure() OWNER TO admin;

--
-- Name: enforce_character_same_adventure_refs(); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.enforce_character_same_adventure_refs() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    r_adv BIGINT;
    l_adv BIGINT;
BEGIN
    IF NEW.race_id IS NOT NULL THEN
        SELECT adventure_id INTO r_adv FROM adventures_race WHERE id = NEW.race_id;
        IF r_adv IS NULL OR r_adv <> NEW.adventure_id THEN
            RAISE EXCEPTION 'Race % belongs to adventure %, but character adventure is %',
                NEW.race_id, r_adv, NEW.adventure_id;
        END IF;
    END IF;

    IF NEW.location_id IS NOT NULL THEN
        SELECT adventure_id INTO l_adv FROM adventures_location WHERE id = NEW.location_id;
        IF l_adv IS NULL OR l_adv <> NEW.adventure_id THEN
            RAISE EXCEPTION 'Location % belongs to adventure %, but character adventure is %',
                NEW.location_id, l_adv, NEW.adventure_id;
        END IF;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.enforce_character_same_adventure_refs() OWNER TO admin;

--
-- Name: enforce_character_system_same_adventure(); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.enforce_character_system_same_adventure() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    c_adv BIGINT;
    s_adv BIGINT;
BEGIN
    SELECT adventure_id INTO c_adv FROM adventures_character WHERE id = NEW.character_id;
    SELECT adventure_id INTO s_adv FROM adventures_skillsystem WHERE id = NEW.system_id;

    IF c_adv IS NULL OR s_adv IS NULL THEN
        RAISE EXCEPTION 'Character % or system % not found', NEW.character_id, NEW.system_id;
    END IF;

    IF NEW.adventure_id <> c_adv OR NEW.adventure_id <> s_adv THEN
        RAISE EXCEPTION 'Adventure mismatch in character_systems: row %, char %, system %',
            NEW.adventure_id, c_adv, s_adv;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.enforce_character_system_same_adventure() OWNER TO admin;

--
-- Name: enforce_character_technique_same_adventure(); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.enforce_character_technique_same_adventure() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    c_adv BIGINT;
    t_adv BIGINT;
BEGIN
    SELECT adventure_id INTO c_adv FROM adventures_character WHERE id = NEW.character_id;
    SELECT adventure_id INTO t_adv FROM adventures_technique WHERE id = NEW.technique_id;

    IF c_adv IS NULL OR t_adv IS NULL THEN
        RAISE EXCEPTION 'Character % or technique % not found', NEW.character_id, NEW.technique_id;
    END IF;

    IF NEW.adventure_id <> c_adv OR NEW.adventure_id <> t_adv THEN
        RAISE EXCEPTION 'Adventure mismatch in character_techniques: row %, char %, tech %',
            NEW.adventure_id, c_adv, t_adv;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.enforce_character_technique_same_adventure() OWNER TO admin;

--
-- Name: enforce_relationship_same_adventure(); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.enforce_relationship_same_adventure() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    from_adv BIGINT;
    to_adv   BIGINT;
BEGIN
    SELECT adventure_id INTO from_adv FROM adventures_character WHERE id = NEW.from_character_id;
    SELECT adventure_id INTO to_adv   FROM adventures_character WHERE id = NEW.to_character_id;

    IF from_adv IS NULL OR to_adv IS NULL THEN
        RAISE EXCEPTION 'Relationship characters not found: % -> %',
            NEW.from_character_id, NEW.to_character_id;
    END IF;

    IF NEW.adventure_id <> from_adv OR NEW.adventure_id <> to_adv THEN
        RAISE EXCEPTION 'Adventure mismatch in relationships: row adv %, from adv %, to adv %',
            NEW.adventure_id, from_adv, to_adv;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.enforce_relationship_same_adventure() OWNER TO admin;

--
-- Name: enforce_technique_same_adventure_as_system(); Type: FUNCTION; Schema: public; Owner: admin
--

CREATE FUNCTION public.enforce_technique_same_adventure_as_system() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    s_adv BIGINT;
BEGIN
    SELECT adventure_id INTO s_adv FROM adventures_skillsystem WHERE id = NEW.system_id;

    IF s_adv IS NULL THEN
        RAISE EXCEPTION 'System % not found', NEW.system_id;
    END IF;

    IF NEW.adventure_id <> s_adv THEN
        RAISE EXCEPTION 'Adventure mismatch: technique adv %, system adv %', NEW.adventure_id, s_adv;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.enforce_technique_same_adventure_as_system() OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: adventures_adventure; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.adventures_adventure (
    id bigint NOT NULL,
    is_template boolean NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    intro text NOT NULL,
    spec_instructions text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    author_user_id bigint NOT NULL,
    player_user_id bigint,
    template_adventure_id bigint,
    primary_hero_id bigint,
    is_waiting_ai boolean NOT NULL,
    rollback_min_history_id bigint,
    CONSTRAINT adventures_template_or_run_chk CHECK (((is_template AND (player_user_id IS NULL) AND (template_adventure_id IS NULL)) OR ((NOT is_template) AND (player_user_id IS NOT NULL) AND (template_adventure_id IS NOT NULL))))
);


ALTER TABLE public.adventures_adventure OWNER TO admin;

--
-- Name: adventures_adventure_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.adventures_adventure ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.adventures_adventure_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: adventures_adventureevent; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.adventures_adventureevent (
    id bigint NOT NULL,
    status text NOT NULL,
    title text NOT NULL,
    trigger_hint text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    adventure_id bigint NOT NULL,
    location_id bigint,
    state text NOT NULL,
    CONSTRAINT events_status_chk CHECK ((status = ANY (ARRAY['inactive'::text, 'active'::text, 'resolved'::text])))
);


ALTER TABLE public.adventures_adventureevent OWNER TO admin;

--
-- Name: adventures_adventureevent_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.adventures_adventureevent ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.adventures_adventureevent_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: adventures_adventureherosetup; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.adventures_adventureherosetup (
    id bigint NOT NULL,
    require_race boolean NOT NULL,
    require_age boolean NOT NULL,
    require_body_power boolean NOT NULL,
    require_mind_power boolean NOT NULL,
    require_will_power boolean NOT NULL,
    require_systems boolean NOT NULL,
    require_techniques boolean NOT NULL,
    adventure_id bigint NOT NULL,
    default_race_id bigint,
    default_age integer,
    default_body_power integer,
    default_mind_power integer,
    default_will_power integer,
    default_location_id bigint,
    CONSTRAINT hero_setup_default_age_nonneg CHECK (((default_age >= 0) OR (default_age IS NULL))),
    CONSTRAINT hero_setup_default_body_nonneg CHECK (((default_body_power >= 0) OR (default_body_power IS NULL))),
    CONSTRAINT hero_setup_default_mind_nonneg CHECK (((default_mind_power >= 0) OR (default_mind_power IS NULL))),
    CONSTRAINT hero_setup_default_will_nonneg CHECK (((default_will_power >= 0) OR (default_will_power IS NULL)))
);


ALTER TABLE public.adventures_adventureherosetup OWNER TO admin;

--
-- Name: adventures_adventureherosetup_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.adventures_adventureherosetup ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.adventures_adventureherosetup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: adventures_adventurehistory; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.adventures_adventurehistory (
    id bigint NOT NULL,
    role text NOT NULL,
    content text NOT NULL,
    metadata jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    adventure_id bigint NOT NULL,
    CONSTRAINT history_role_chk CHECK ((role = ANY (ARRAY['user'::text, 'ai'::text, 'system'::text])))
);


ALTER TABLE public.adventures_adventurehistory OWNER TO admin;

--
-- Name: adventures_adventurehistory_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.adventures_adventurehistory ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.adventures_adventurehistory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: adventures_adventurememory; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.adventures_adventurememory (
    id bigint NOT NULL,
    kind text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    importance integer NOT NULL,
    tags text[] NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    adventure_id bigint NOT NULL,
    CONSTRAINT memories_kind_chk CHECK ((kind = ANY (ARRAY['summary'::text, 'fact'::text, 'rule'::text, 'goal'::text])))
);


ALTER TABLE public.adventures_adventurememory OWNER TO admin;

--
-- Name: adventures_adventurememory_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.adventures_adventurememory ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.adventures_adventurememory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: adventures_character; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.adventures_character (
    id bigint NOT NULL,
    is_player boolean NOT NULL,
    title text NOT NULL,
    age integer,
    body_power integer NOT NULL,
    mind_power integer NOT NULL,
    will_power integer NOT NULL,
    description text NOT NULL,
    tags text[] NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    adventure_id bigint NOT NULL,
    location_id bigint,
    race_id bigint,
    in_party boolean NOT NULL,
    body_power_progress integer NOT NULL,
    mind_power_progress integer NOT NULL,
    will_power_progress integer NOT NULL,
    CONSTRAINT characters_age_non_negative CHECK (((age >= 0) OR (age IS NULL))),
    CONSTRAINT characters_body_non_negative CHECK ((body_power >= 0)),
    CONSTRAINT characters_body_progress_range CHECK (((body_power_progress >= 0) AND (body_power_progress <= 100))),
    CONSTRAINT characters_mind_non_negative CHECK ((mind_power >= 0)),
    CONSTRAINT characters_mind_progress_range CHECK (((mind_power_progress >= 0) AND (mind_power_progress <= 100))),
    CONSTRAINT characters_will_non_negative CHECK ((will_power >= 0)),
    CONSTRAINT characters_will_progress_range CHECK (((will_power_progress >= 0) AND (will_power_progress <= 100)))
);


ALTER TABLE public.adventures_character OWNER TO admin;

--
-- Name: adventures_character_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.adventures_character ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.adventures_character_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: adventures_characterfaction; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.adventures_characterfaction (
    id bigint NOT NULL,
    adventure_id bigint NOT NULL,
    character_id bigint NOT NULL,
    faction_id bigint NOT NULL
);


ALTER TABLE public.adventures_characterfaction OWNER TO admin;

--
-- Name: adventures_characterfaction_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.adventures_characterfaction ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.adventures_characterfaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: adventures_characterrelationship; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.adventures_characterrelationship (
    id bigint NOT NULL,
    kind text NOT NULL,
    description text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    adventure_id bigint NOT NULL,
    from_character_id bigint NOT NULL,
    to_character_id bigint NOT NULL,
    CONSTRAINT rel_not_self CHECK ((NOT (from_character_id = to_character_id)))
);


ALTER TABLE public.adventures_characterrelationship OWNER TO admin;

--
-- Name: adventures_characterrelationship_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.adventures_characterrelationship ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.adventures_characterrelationship_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: adventures_charactersystem; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.adventures_charactersystem (
    id bigint NOT NULL,
    level integer NOT NULL,
    notes text NOT NULL,
    adventure_id bigint NOT NULL,
    character_id bigint NOT NULL,
    system_id bigint NOT NULL,
    progress_percent integer NOT NULL,
    CONSTRAINT character_system_level_nonneg CHECK ((level >= 0)),
    CONSTRAINT character_system_progress_pct CHECK (((progress_percent >= 0) AND (progress_percent <= 100)))
);


ALTER TABLE public.adventures_charactersystem OWNER TO admin;

--
-- Name: adventures_charactersystem_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.adventures_charactersystem ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.adventures_charactersystem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: adventures_charactertechnique; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.adventures_charactertechnique (
    id bigint NOT NULL,
    learned_at timestamp with time zone NOT NULL,
    notes text NOT NULL,
    adventure_id bigint NOT NULL,
    character_id bigint NOT NULL,
    technique_id bigint NOT NULL
);


ALTER TABLE public.adventures_charactertechnique OWNER TO admin;

--
-- Name: adventures_charactertechnique_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.adventures_charactertechnique ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.adventures_charactertechnique_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: adventures_faction; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.adventures_faction (
    id bigint NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    tags text[] NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    adventure_id bigint NOT NULL
);


ALTER TABLE public.adventures_faction OWNER TO admin;

--
-- Name: adventures_faction_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.adventures_faction ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.adventures_faction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: adventures_location; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.adventures_location (
    id bigint NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    x integer NOT NULL,
    y integer NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    tags text[] NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    adventure_id bigint NOT NULL,
    CONSTRAINT locations_height_gt_zero CHECK ((height > 0)),
    CONSTRAINT locations_width_gt_zero CHECK ((width > 0))
);


ALTER TABLE public.adventures_location OWNER TO admin;

--
-- Name: adventures_location_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.adventures_location ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.adventures_location_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: adventures_moderationentry; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.adventures_moderationentry (
    adventure_id bigint NOT NULL,
    submitted_at timestamp with time zone NOT NULL
);


ALTER TABLE public.adventures_moderationentry OWNER TO admin;

--
-- Name: adventures_otherinfo; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.adventures_otherinfo (
    id bigint NOT NULL,
    category text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    tags text[] NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    adventure_id bigint NOT NULL
);


ALTER TABLE public.adventures_otherinfo OWNER TO admin;

--
-- Name: adventures_otherinfo_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.adventures_otherinfo ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.adventures_otherinfo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: adventures_publishedadventure; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.adventures_publishedadventure (
    adventure_id bigint NOT NULL,
    published_at timestamp with time zone NOT NULL
);


ALTER TABLE public.adventures_publishedadventure OWNER TO admin;

--
-- Name: adventures_race; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.adventures_race (
    id bigint NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    tags text[] NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    adventure_id bigint NOT NULL,
    life_span integer NOT NULL
);


ALTER TABLE public.adventures_race OWNER TO admin;

--
-- Name: adventures_race_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.adventures_race ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.adventures_race_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: adventures_skillsystem; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.adventures_skillsystem (
    id bigint NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    tags text[] NOT NULL,
    w_body integer NOT NULL,
    w_mind integer NOT NULL,
    w_will integer NOT NULL,
    formula_hint text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    adventure_id bigint NOT NULL,
    CONSTRAINT skill_systems_weights_nonneg CHECK (((w_body >= 0) AND (w_mind >= 0) AND (w_will >= 0))),
    CONSTRAINT skill_systems_weights_not_all_zero CHECK (((w_body > 0) OR (w_mind > 0) OR (w_will > 0)))
);


ALTER TABLE public.adventures_skillsystem OWNER TO admin;

--
-- Name: adventures_skillsystem_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.adventures_skillsystem ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.adventures_skillsystem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: adventures_technique; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.adventures_technique (
    id bigint NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    tags text[] NOT NULL,
    difficulty integer NOT NULL,
    tier integer,
    required_system_level integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    adventure_id bigint NOT NULL,
    system_id bigint NOT NULL,
    CONSTRAINT techniques_difficulty_nonneg CHECK ((difficulty >= 0)),
    CONSTRAINT techniques_required_level_nonneg CHECK ((required_system_level >= 0)),
    CONSTRAINT techniques_tier_nonneg CHECK (((tier >= 0) OR (tier IS NULL)))
);


ALTER TABLE public.adventures_technique OWNER TO admin;

--
-- Name: adventures_technique_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.adventures_technique ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.adventures_technique_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO admin;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.auth_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO admin;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.auth_group_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO admin;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.auth_permission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: authtoken_token; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.authtoken_token (
    key character varying(40) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.authtoken_token OWNER TO admin;

--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id bigint NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO admin;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.django_admin_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO admin;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.django_content_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO admin;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.django_migrations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO admin;

--
-- Name: users_administrator; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.users_administrator (
    id bigint NOT NULL,
    level smallint NOT NULL,
    user_id bigint NOT NULL,
    CONSTRAINT users_administrator_level_check CHECK ((level >= 0))
);


ALTER TABLE public.users_administrator OWNER TO admin;

--
-- Name: users_administrator_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.users_administrator ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_administrator_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users_user; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.users_user (
    id bigint NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    email character varying(254) NOT NULL,
    credits integer NOT NULL,
    CONSTRAINT users_user_credits_check CHECK ((credits >= 0))
);


ALTER TABLE public.users_user OWNER TO admin;

--
-- Name: users_user_groups; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.users_user_groups (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.users_user_groups OWNER TO admin;

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.users_user_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.users_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users_user_user_permissions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.users_user_user_permissions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.users_user_user_permissions OWNER TO admin;

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.users_user_user_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: adventures_adventure; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.adventures_adventure (id, is_template, title, description, intro, spec_instructions, created_at, updated_at, author_user_id, player_user_id, template_adventure_id, primary_hero_id, is_waiting_ai, rollback_min_history_id) FROM stdin;
1	t	Битва за Вест-Харбор	Праздник оборачивается трагедией, когда посреди ночи вашу деревню атакуют ужасные существа из легенд	- Вставай! Вставай! На нас напали! - пробивается сквозь сон встревоженный голос.\n- Бивил? - бормочет <main_hero>.\n- Вставай, Западная Гавань атакована!\n<main_hero> резко открывает глаза и садится. \nПрямо перед ним стоят друзья: Бивил и Эми. Они тяжело дышат, но в их глазах облегчение - они оказались быстрее вторженцев.	Не спеши продвигать сюжет вперёд. Если игрок (пользователь) что-то пишет, и это идёт в канве истории, старайся развивать эту линию повествования.	2025-12-23 04:01:10.670809+03	2025-12-25 20:37:45.330164+03	2	\N	\N	37	f	\N
18	f	Битва за Вест-Харбор	Праздник оборачивается трагедией, когда посреди ночи вашу деревню атакуют ужасные существа из легенд	- Вставай! Вставай! На нас напали! - пробивается сквозь сон встревоженный голос.\n- Бивил? - бормочет <main_hero>.\n- Вставай, Западная Гавань атакована!\n<main_hero> резко открывает глаза и садится. \nПрямо перед ним стоят друзья: Бивил и Эми. Они тяжело дышат, но в их глазах облегчение - они оказались быстрее вторженцев.	Не спеши продвигать сюжет вперёд. Если игрок (пользователь) что-то пишет, и это идёт в канве истории, старайся развивать эту линию повествования.	2025-12-25 20:43:20.318576+03	2025-12-25 20:43:20.318586+03	2	3	1	84	f	297
16	f	Битва за Вест-Харбор (главное)	Праздник оборачивается трагедией, когда посреди ночи вашу деревню атакуют ужасные существа из легенд	- Вставай! Вставай! На нас напали! - пробивается сквозь сон встревоженный голос.\n- Бивил? - бормочет <main_hero>.\n- Вставай, Западная Гавань атакована!\n<main_hero> резко открывает глаза и садится. \nПрямо перед ним (ней) стоят друзья: Бивил и Эми. Они тяжело дышат, но в их глазах облегчение - они оказались быстрее вторженцев.	Не спеши продвигать сюжет вперёд. Если игрок (пользователь) что-то пишет, и это идёт в канве истории, старайся развивать эту линию повествования.	2025-12-24 06:20:08.617948+03	2025-12-24 06:20:08.617955+03	2	2	1	74	f	275
\.


--
-- Data for Name: adventures_adventureevent; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.adventures_adventureevent (id, status, title, trigger_hint, created_at, updated_at, adventure_id, location_id, state) FROM stdin;
1	active	Нападение на Западную Гавань		2025-12-23 20:30:42.600535+03	2025-12-24 00:16:49.853745+03	1	\N	Поселение Западная Гавань атаковано.\nЖители Западной Гавани застаны врасплох, и не знают, кто на них напал. Люди дезорганизованы. Треть ополчение собрано под руководством Георгия Редфелла, и есть задача собрать других ополченцев, многие из которых сидят дома и боятся выйти на улицу.\nПо всему поселению хаос, блейдлинги и серые дворфы рыщут малыми группами, врываются в дома и атакуют людей.\nНападением руководит волшебник гитиянки, она командует войсками из тридцати семи блейдлингов и сорока серых дворфов. Они ищут некий осколок, но при этом безжалостны к местному населению.
16	active	Нападение на Западную Гавань		2025-12-24 06:20:08.640946+03	2025-12-24 06:20:08.640958+03	16	\N	Поселение Западная Гавань атаковано.\nЖители Западной Гавани застаны врасплох, и не знают, кто на них напал. Люди дезорганизованы. Треть ополчение собрано под руководством Георгия Редфелла, и есть задача собрать других ополченцев, многие из которых сидят дома и боятся выйти на улицу.\nПо всему поселению хаос, блейдлинги и серые дворфы рыщут малыми группами, врываются в дома и атакуют людей.\nНападением руководит волшебник гитиянки, она командует войсками из тридцати семи блейдлингов и сорока серых дворфов. Они ищут некий осколок, но при этом безжалостны к местному населению.\nГеорг, Эми, Бивил и Тармас отправились на поиски артефакта. Эми использует заклинания для магического сканирования местности, Тармас следит за изменениями в магическом фоне, Георг и Бивил осматривают окрестности.\nОтряд наткнулся на древний дольмен, покрытый загадочными рунами. Эми начала изучать символы, Тармас настороженно оглядывается по сторонам, подозревая ловушку. Георг и Бивил охраняют группу от возможного нападения. Внезапно руны на дольмене засветились...
18	resolved	Нападение на Западную Гавань		2025-12-25 20:43:20.328418+03	2025-12-25 20:43:20.328421+03	18	\N	Поселение Западная Гавань атаковано. Жители Западной Гавани застаны врасплох, и не знают, кто на них напал. Люди дезорганизованы. Треть ополчение собрано под руководством Георгия Редфелла, и есть задача собрать других ополченцев, многие из которых сидят дома и боятся выйти на улицу. По всему поселению хаос, блейдлинги и серые дворфы рыщут малыми группами, врываются в дома и атакуют людей. Нападением руководит волшебник гитиянки, она командует войсками из тридцати семи блейдлингов и сорока серых дворфов. Они ищут некий осколок, но при этом безжалостны к местному населению. Ополченцы, воодушевлённые успехом, сражаются с удвоенной силой, тесня захватчиков к окраинам села. Захватчики начинают терять боевой дух, некоторые из них бросают оружие и пытаются бежать. Гитиянка отступает, магия вокруг неё гаснет, и она скрывается в тени. Ополченцы выстояли, но цена победы высока — много разрушений и крови.
\.


--
-- Data for Name: adventures_adventureherosetup; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.adventures_adventureherosetup (id, require_race, require_age, require_body_power, require_mind_power, require_will_power, require_systems, require_techniques, adventure_id, default_race_id, default_age, default_body_power, default_mind_power, default_will_power, default_location_id) FROM stdin;
1	t	t	t	t	t	f	f	1	\N	\N	\N	\N	\N	1
15	t	t	t	t	t	f	f	16	\N	\N	\N	\N	\N	31
17	t	t	t	t	t	f	f	18	\N	\N	\N	\N	\N	35
\.


--
-- Data for Name: adventures_adventurehistory; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.adventures_adventurehistory (id, role, content, metadata, created_at, adventure_id) FROM stdin;
206	ai	Блейдлинги оказывают ожесточённое сопротивление, но ополченцы, благодаря благословению и умелому руководству Георга и Бивила, постепенно теснят их. Эми поддерживает щит и периодически использует «Волшебную стрелу», поражая врагов издалека. Внезапно из-за ручья раздаётся новый шум — похоже, приближается ещё одна группа нападающих. Георг готовится к новой волне атаки.	{}	2025-12-24 06:20:28.506186+03	16
213	ai	Бивил с несколькими ополченцами ринулся к гитиянке, отвлекая её внимание яростной атакой. Георг и Эми укрылись за углом дома, обдумывая план. Эми создала яркий «Свет», пытаясь ослепить гитиянку и нарушить её концентрацию, а Георг вознёс молитву, усиливая свою волю для предстоящей магической схватки. Воздух дрожал от напряжения — решающий момент приближался.	{}	2025-12-24 06:20:47.888494+03	16
220	ai	Серые дворфы и блейдлинги, осознав, что сражение оборачивается не в их пользу, начали отступать к ручью. Георг, видя перелом в битве, поднял руку и громко провозгласил победу. Ополченцы восторженно закричали, празднуя успех. Эми ослабила «Щит мага», а Тармас прекратил магические атаки. Бивил, тяжело дыша, подошёл к Георгу и крепко пожал ему руку, поздравляя с победой.	{}	2025-12-24 06:21:08.575953+03	16
227	ai	Несколько дней проходят в напряжённой подготовке. Ополчение тренируется всё усерднее, магические ловушки расставлены по всему селу, а укрепления у моста становятся всё надёжнее. Георг, Эми, Бивил и Тармас регулярно сверяют планы и обсуждают любые подозрительные признаки. В селе царит атмосфера готовности к новому нападению, но вместе с тем — уверенности в своих силах и решимости защищать Западную Гавань до последнего.	{}	2025-12-24 06:21:32.42498+03	16
234	ai	Огненный шар Тармаса застал гитиянку врасплох, но она успела выставить защитный барьер. Однако заклинание гитиянки было нарушено, и луч, направленный на мост, рассеялся. Бивил, уловив момент, повёл ополченцев в решительную контратаку. Георг вознёс новую молитву, укрепляя дух товарищей, а Эми, собрав остатки сил, усилила «Свет», освещая поле боя и помогая союзникам целиться.	{}	2025-12-24 06:21:56.410076+03	16
265	ai	Однажды, во время очередного совещания, Тармас сообщил о странных магических колебаниях в окрестностях Западной Гавани. Георг, Эми и Бивил переглянулись — это могло означать возвращение врагов или появление новой угрозы. Решено было усилить патрули и подготовить все силы к возможной атаке, а Тармас взялся за детальное исследование источника колебаний.	{}	2025-12-24 06:34:52.349605+03	16
271	ai	Георг, Эми, Бивил и Тармас во главе отряда ополченцев отправились на поиски артефакта. Они методично обследовали окрестности Западной Гавани, используя магические способности Эми и опыт Тармаса. Напряжение витало в воздухе — никто не знал, что за сила скрывается в артефакте и кто его владелец. С каждым часом неопределённость только нарастала, заставляя героев быть начеку.	{}	2025-12-24 06:41:31.803423+03	16
277	ai	После нескольких часов поисков отряд наткнулся на древний дольмен, покрытый загадочными рунами. Эми, почувствовав всплеск магической энергии, осторожно приблизилась к нему и начала изучать символы. Тармас настороженно оглядывался по сторонам, подозревая ловушку. Георг и Бивил, держа оружие наготове, охраняли группу от возможного нападения. Внезапно руны на дольмене засветились...	{}	2025-12-24 06:46:31.122909+03	16
285	system	- Вставай! Вставай! На нас напали! - пробивается сквозь сон встревоженный голос.\n- Бивил? - бормочет Георг.\n- Вставай, Западная Гавань атакована!\nГеорг резко открывает глаза и садится. \nПрямо перед ним стоят друзья: Бивил и Эми. Они тяжело дышат, но в их глазах облегчение - они оказались быстрее вторженцев.	{}	2025-12-25 20:43:20.334164+03	18
296	user	Георг: Я сдвигаю стойку и на мгновение отступаю на полшага, оценивая новые тени.\n— Их больше… — выдыхаю я, не отводя клинка. — Бивил, держи фланг. Эми — будь готова.\nЯ вновь поднимаю меч, решив встретить следующую волну так же твёрдо, как первую.	{}	2025-12-25 20:50:52.405108+03	18
297	ai	Новые враги стремительно приближаются. Георг чувствует, как напряжение нарастает, но сила веры не покидает его. Он видит, как Эми готовится запустить «Волшебную стрелу», а Бивил занимает более удобную позицию. Георг поднимает руку, давая знак к совместному удару, и в тот же миг небо разрезает вспышка магии — Эми наносит первый удар.	{}	2025-12-25 20:50:54.118837+03	18
207	ai	Из-за ручья появляются серые дворфы, их больше, чем было блейдлингов. Георг быстро перестраивает отряды, приказывая части ополченцев закрепиться у моста, а другим — подготовиться к отражению атаки с флангов. Бивил принимает на себя руководство центральным отрядом, а Эми усиливает «Щит мага», чтобы защитить товарищей от возможных магических атак противника. Напряжение достигает апогея.	{}	2025-12-24 06:20:31.26961+03	16
214	ai	Гитиянка, отвлечённая атакой Бивила, на мгновение потеряла концентрацию, и магические узоры в воздухе дрогнули. Георг, почувствовав момент слабости, вознёс руку и произнёс молитву, усиливая «Доспех веры» на Эми и себе. Эми тем временем направила «Волшебную стрелу» прямо в сторону гитиянки, пытаясь нарушить её магические плетения.	{}	2025-12-24 06:20:50.893695+03	16
221	ai	После победы жители Западной Гавани начали собирать раненых и оказывать им помощь. Георг, Эми, Бивил и Тармас обходят село, проверяя, кто пострадал и кому нужна поддержка. В воздухе витает облегчение, но все понимают — угроза ещё не полностью устранена. Необходимо укрепить оборону и выяснить, зачем нападавшие искали осколок.	{}	2025-12-24 06:21:11.294736+03	16
228	ai	Однажды ночью, когда всё село было погружено в темноту, тревожный звон колокола разорвал тишину. Георг, Эми, Бивил и Тармас мгновенно собрались и выбежали на улицу. В небе мерцали странные огни, а в воздухе чувствовалась магия. Похоже, враги вернулись, и на этот раз их атака могла быть ещё более сокрушительной.	{}	2025-12-24 06:21:36.149726+03	16
235	ai	Серые дворфы и блейдлинги, не выдержав натиска, начали отступать. Георг, видя перелом в битве, поднял меч и громко провозгласил: «Мы снова победили!» Ополченцы восторженно закричали. Эми ослабила «Щит мага», а Тармас прекратил магические атаки. Бивил, тяжело дыша, подошёл к Георгу и сказал: «Они не скоро решатся напасть снова».	{}	2025-12-24 06:22:10.618172+03	16
272	ai	После второй победы над захватчиками жители Западной Гавани с новыми силами принялись за восстановление порядка в селе. Георг организовал группу для ремонта повреждённых домов, Эми изучала остатки магических следов, пытаясь понять, что именно искали враги, а Бивил вместе с ополченцами укреплял оборонительные сооружения. Тармас обещал продолжить магическую разведку и выяснить, не готовят ли нападавшие новое вторжение.	{}	2025-12-24 06:41:47.470651+03	16
278	ai	Поиски артефакта затянулись. День клонился к вечеру, а никаких следов загадочного предмета не было. Георг начал беспокоиться — усталость отряда росла, а напряжение не спадало. Эми чувствовала, что магический фон становится всё более нестабильным, и это тревожило её. Тармас, погружённый в свои размышления, вдруг остановился и поднял руку, призывая всех к тишине.	{}	2025-12-24 06:46:38.909362+03	16
286	user	Георг: Я вздрагиваю и резко сажусь на постели, сбрасывая остатки сна. В комнате темно и холодно, я инстинктивно прикрываюсь одеялом и бросаю взгляд на друзей.\n\n— Западную Гавань?.. — переспрашиваю тише, уже понимая серьёзность. — Ладно… дайте секунду. Где они сейчас?	{}	2025-12-25 20:43:33.279547+03	18
287	ai	Бивил быстро отвечает:\n— Враги рыщут по всему селу, врываются в дома. Мы видели группы блейдлингов и серых дворфов. Георгий Редфелл собрал треть ополчения, но нужно собрать остальных.\n\nЭми добавляет:\n— Нужно действовать быстро, они ищут какой-то осколок и не щадят местных. Я уже подготовилась к бою — зарядила несколько заклинаний.	{}	2025-12-25 20:43:35.283314+03	18
298	user	Георг: Я резко киваю и иду вперёд, используя вспышку как прикрытие.\n— Сейчас! — бросаю я и врываюсь в строй врагов, не давая им опомниться.\nВера ведёт мою руку точно, и я бью первым, чтобы сломать их натиск.	{}	2025-12-25 20:52:04.753552+03	18
299	ai	Блейдлинги пытаются сопротивляться, но слаженные действия героев не дают им шанса. Георг чувствует, как каждый его удар становится всё более мощным благодаря силе веры. Бивил ловко уворачивается от атак и наносит ответные удары, а Эми поддерживает друзей магическими импульсами. Однако где-то вдалеке слышны новые крики — похоже, что опасность ещё не миновала.	{}	2025-12-25 20:52:08.887682+03	18
308	user	Георг: Я сжимаю рукоять и смещаюсь вперёд, закрывая брешь.\n— Ещё волна… — выдыхаю я ровно. — Держитесь за свет.\nЯ поднимаю меч навстречу новым силуэтам, готовый принять их удар и не дать строю сломаться.	{}	2025-12-25 20:58:01.3914+03	18
208	ai	Серые дворфы стремительно приближаются, их оружие блестит в свете, создаваемом Эми. Георг использует «Доспех веры», чтобы усилить защиту ключевых бойцов. Бивил ведёт центральный отряд в контратаку, умело маневрируя. Ополченцы, вдохновлённые лидерством Георга и поддержкой друзей, сражаются с удвоенной силой, сдерживая натиск врагов. В воздухе витает запах дыма и железа, бой становится всё более ожесточённым.	{}	2025-12-24 06:20:34.212401+03	16
215	ai	Стрела Эми прорезала воздух, но гитиянка успела выставить защитный барьер. Однако её магические узоры вновь дрогнули — молитва Георга усилила защиту союзников и ослабила врага. Бивил продолжал яростно атаковать, не давая гитиянке сосредоточиться. В этот момент Тармас послал ещё один «Огненный шар», целясь в группу серых дворфов, которые пытались обойти защитников с фланга.	{}	2025-12-24 06:20:54.251819+03	16
222	ai	Георг решает собрать совет из наиболее уважаемых жителей села, чтобы обсудить дальнейшие действия. Эми предлагает проанализировать следы и остатки магических плетений, чтобы понять, что именно искали нападавшие. Бивил тем временем организует патрули для охраны Западной Гавани. Тармас обещает помочь с магической разведкой и выяснить, нет ли поблизости других вражеских сил.	{}	2025-12-24 06:21:14.180077+03	16
229	ai	Георг быстро распределил задачи: Бивилу предстояло возглавить ополчение и занять оборону у моста, Эми — поддерживать «Щит мага» и быть готовой к магической контратаке, Тармасу — отслеживать перемещения врагов с помощью заклинаний. Сам Георг вознёс молитву, усиливая волю защитников и готовясь применить «Благословение оружия», как только начнётся сражение. В селе царила напряжённая тишина, прерываемая лишь шагами вооружённых жителей.	{}	2025-12-24 06:21:39.749463+03	16
273	ai	Дни текут за днями, и жизнь в Западной Гавани постепенно входит в колею, хотя бдительность не ослабевает. Георг, Эми, Бивил и Тармас продолжают совершенствовать оборону села. Жители, вдохновлённые успехами, активно участвуют в укреплении защиты. Но в воздухе витает предчувствие — все понимают, что это лишь затишье перед бурей, и враг может вернуться в любой момент с новыми силами и планами.	{}	2025-12-24 06:43:25.097127+03	16
279	ai	Однажды ночью Георг проснулся от странного ощущения — будто кто-то наблюдает за селом. Он вышел на улицу и заметил едва уловимые магические всполохи на горизонте. Немедленно собрав Эми, Бивила и Тармаса, Георг поделился своими наблюдениями. Тармас подтвердил: вражеская магия снова рядом, и угроза может материализоваться в любой момент.	{}	2025-12-24 06:46:48.826236+03	16
288	user	Георг: Я сжимаю зубы и киваю, уже стаскивая с кровати штаны и рубаху.\n\n— Тогда медлить нельзя, — говорю я, натягивая одежду. — Если Редфелл у ополчения, идём к нему. По дороге поднимем тех, кто ещё может держать оружие.	{}	2025-12-25 20:45:32.493135+03	18
289	ai	Бивил кивает и бросается к двери, на ходу подхватывая свой меч. Эми следом устремляется за ним, её пальцы слегка подрагивают, выдавая внутреннее напряжение. Георг на мгновение замирает, чтобы мысленно собраться, затем быстро следует за друзьями, на ходу активируя «Благословение оружия» и ощущая, как сила веры наполняет его.	{}	2025-12-25 20:45:35.26266+03	18
300	user	Георг: Я перевожу дыхание и на мгновение оглядываюсь на тёмные улицы.\n— Это ещё не конец, — говорю я глухо, стирая кровь с клинка.\n— Вперёд, к ополчению. Пока мы здесь — люди не останутся одни.	{}	2025-12-25 20:54:16.529435+03	18
301	ai	Группа продвигается дальше, и вскоре они видят огни факелов — это ополчение. Георгий Редфелл поднимает руку, приветствуя Георга, Бивила и Эми. Он кратко сообщает о ситуации: враги активно ищут осколок, многие дома уже разграблены. Георг кивает и предлагает разработать план действий, чтобы скоординировать усилия и дать отпор захватчикам.	{}	2025-12-25 20:54:19.870086+03	18
309	ai	Новый отряд захватчиков стремительно приближается. Георг ощущает, как напряжение достигает пика, но сила веры не покидает его. Он видит, как Эми готовится запустить «Волшебную стрелу», а Бивил занимает более выгодную позицию. Ополченцы держатся стойко, ожидая сигнала. Георг поднимает руку, давая знак к совместному удару, и в тот же миг небо снова разрезает вспышка магии.	{}	2025-12-25 20:58:04.56365+03	18
209	ai	Среди хаоса боя Георг замечает, как несколько серых дворфов пытаются обойти ополченцев с тыла. Он срочно перебрасывает часть бойцов для блокировки флангового манёвра. Эми усиливает «Свет», чтобы осветить тыловые подступы и не дать врагу скрыться. Бивил, отбивая атаки в центре, кричит об опасности и призывает товарищей быть бдительными. Бой затягивается, но дух сопротивления не угасает.	{}	2025-12-24 06:20:36.879134+03	16
216	ai	Гитиянка, раздражённая непрекращающимися атаками, выпустила в ответ мощное заклинание. Эми мгновенно отреагировала, усилив «Щит мага», чтобы поглотить часть удара. Георг, видя опасность, приказал ополченцам усилить давление на врагов, чтобы отвлечь внимание гитиянки. Бивил, несмотря на усталость, продолжал яростно сражаться, пробиваясь сквозь ряды противников и давая союзникам драгоценное время.	{}	2025-12-24 06:20:57.128047+03	16
223	ai	Совет собирается в доме старейшины. Георг кратко излагает ситуацию, подчёркивая необходимость укрепить оборону и выяснить цель нападения. Эми делится своими наблюдениями о магических следах, предполагая, что осколок может быть где-то в селе. Бивил докладывает о готовности патрулей. Тармас обещает исследовать окрестности с помощью своих заклинаний и выяснить, ушли ли враги окончательно.	{}	2025-12-24 06:21:17.131153+03	16
230	ai	Внезапно из темноты появились силуэты блейдлингов и серых дворфов. Они двигались тихо, но целеустремлённо, окружая село. Бивил поднял свой меч и дал сигнал ополченцам занять позиции. Эми усилила «Щит мага», чувствуя нарастающую магическую угрозу. Тармас прошептал заклинание, и в небе вспыхнули символы, указывающие на расположение вражеских групп. Георг вознёс руки, готовясь благословить оружие защитников.	{}	2025-12-24 06:21:42.658075+03	16
274	ai	Однажды во время совещания Георг предложил отправить разведчиков в окрестности Западной Гавани, чтобы выяснить, откуда появляются враги и где их основная база. Эми поддержала идею, предложив использовать магические средства для отслеживания следов блейдлингов и серых дворфов. Бивил вызвался возглавить отряд разведчиков, и Тармас пообещал помочь с магической поддержкой. Жители с волнением провожали отважных героев.	{}	2025-12-24 06:44:58.014749+03	16
280	ai	Бивил с группой ополченцев и Тармас с Эми отправились на разведку. Они двигались осторожно, внимательно изучая местность и следы. Эми использовала магические заклинания для обнаружения признаков присутствия врагов, а Тармас следил за изменениями в магическом фоне. Вскоре они заметили странные знаки на деревьях и непонятные следы, которые могли указывать на базу захватчиков.	{}	2025-12-24 06:46:57.962285+03	16
290	user	Георг: Я перехватываю дыхание и выхожу следом, позволяя благословению окончательно закрепиться во мне. Холод ночи кусает кожу, но внутри — ровный, ясный жар.\n\n— Веди, Бивил, — тихо говорю я. — Сначала ополчение. Потом — гости.	{}	2025-12-25 20:47:49.849163+03	18
291	ai	Бивил уверенно ведёт группу по тёмным улицам, указывая на места, где видели врагов. Иногда слышны крики и шум боя — нападение не ослабевает. Георг внимательно осматривает окрестности, готовый отразить атаку. Эми идёт чуть позади, держа руку на амулете и шепча заклинания, чтобы быть готовой к любому повороту событий. Вскоре они приближаются к месту сбора ополчения.	{}	2025-12-25 20:47:52.315391+03	18
302	user	Георг: Я выхожу к свету факелов и коротко склоняю голову Редфеллу.\n— Врага надо перехватывать группами, не дав им рыскать по домам, — говорю я спокойно.\n— Соберите людей в отряды и держите центр села. Мы ударим там, где они прорвутся первыми.	{}	2025-12-25 20:55:05.928076+03	18
303	ai	Георгий Редфелл кивает, принимая предложение Георга. Ополченцы начинают перегруппировку, разделяясь на небольшие отряды и занимая позиции в центре села. Георг, Бивил и Эми остаются с Редфеллом, чтобы координировать действия. В воздухе витает напряжение — все понимают, что битва только начинается. Вдруг откуда-то доносится громкий крик, и все оборачиваются в сторону звука.	{}	2025-12-25 20:55:08.903258+03	18
310	user	Георг: Я резко опускаю руку и делаю шаг вперёд.\n— Сейчас, — говорю я глухо.\nПод вспышкой магии я врываюсь в их строй, принимая первый удар на себя и не позволяя врагам сомкнуться вокруг ополченцев.	{}	2025-12-25 20:58:37.856836+03	18
312	user	Георг: Я задерживаю дыхание и быстро оглядываюсь на тёмную улицу.\n— Они тянут силы со всего села… — тихо говорю я.\nЯ выпрямляюсь и сжимаю меч крепче. — Значит, здесь их и остановим.	{}	2025-12-25 20:59:14.025235+03	18
210	ai	Вдруг в небе вспыхивает яркий свет — это Тармас, эльфийский волшебник, вступает в бой. Он посылает «Огненный шар» в гущу врагов, создавая хаос среди серых дворфов. Георг, увидев подкрепление, воодушевляется и кричит о победе, побуждая ополченцев к новым атакам. Эми усиливает «Щит мага», защищая Тармаса и товарищей от контратаки. Битва достигает кульминации.	{}	2025-12-24 06:20:39.776013+03	16
217	ai	Напряжение достигло пика — гитиянка начала плести новое, ещё более мощное заклинание. Георг, ощущая опасность, призвал всех к единству и стойкости. Эми, собрав все силы, удвоила мощь «Щита мага», а Тармас приготовился к новой атаке. Ополченцы, вдохновлённые лидерами, с новой силой бросились в бой, пытаясь сокрушить ряды врагов и не дать гитиянке завершить опасное заклинание.	{}	2025-12-24 06:20:59.975493+03	16
224	ai	Тармас уходит на магическую разведку, а Георг, Эми и Бивил начинают обыск в селе — проверяют подвалы, заброшенные дома и другие укромные места, где может скрываться осколок. Жители, воодушевлённые победой, помогают искать. Напряжение понемногу спадает, но атмосфера настороженности всё ещё витает в воздухе — все понимают, что опасность может вернуться в любой момент.	{}	2025-12-24 06:21:20.147237+03	16
231	ai	Блейдлинги и серые дворфы ринулись в атаку, пытаясь прорваться через оборону у моста. Бивил, яростно размахивая мечом, отражал удары, направляя ополченцев в самые опасные участки. Эми поддерживала «Щит мага», отбивая магические атаки гитиянки. Тармас посылал «Огненные шары» в гущу врагов, а Георг, произнеся молитву, наложил «Благословение оружия» на ключевые группы бойцов, усиливая их решимость и силу.	{}	2025-12-24 06:21:46.25254+03	16
263	ai	После второй победы над захватчиками жители Западной Гавани с новой силой взялись за укрепление обороны. Георг организовал постоянные учения ополчения, Эми совершенствовала магические ловушки, а Бивил вместе с добровольцами укреплял защитные сооружения. Тармас пообещал регулярно проводить магическую разведку, чтобы вовремя обнаружить приближение врага. В селе царила атмосфера напряжённого ожидания и готовности к новой угрозе.	{}	2025-12-24 06:34:14.960325+03	16
275	ai	Тармас вернулся через несколько часов, его лицо было серьёзным. Он сообщил, что магические колебания исходят не от знакомых врагов, а от чего-то неизвестного и, возможно, гораздо более опасного. Георг приказал усилить все защитные меры и подготовить ополчение к бою. Эми начала готовить новые заклинания, а Бивил — проверять оружие и снаряжение. Напряжение в селе вновь возросло.	{}	2025-12-24 06:45:23.705305+03	16
281	ai	Ночью небо над Западной Гаванью озарила странная аура — магические колебания усилились. Георг, Эми, Бивил и Тармас собрались у окраины села, чтобы выяснить источник угрозы. Тармас начал плести сложное заклинание, Эми поддерживала его «Светом», а Георг и Бивил держали наготове оружие. Внезапно из леса донёсся шёпот неизвестных существ...	{}	2025-12-24 06:47:12.930541+03	16
292	user	Георг: Я сжимаю рукоять оружия и замедляю шаг, вслушиваясь в ночь.\n— Здесь они могут ударить из-за домов, — шепчу я, окидывая улицу взглядом. — Держимся вместе… и будьте готовы.	{}	2025-12-25 20:48:22.076597+03	18
293	ai	Группа осторожно продвигается дальше. Внезапно из-за угла одного из домов выскакивает группа блейдлингов. Бивил с громким криком бросается в атаку, Эми тут же поднимает щит мага, защищая друзей. Георг активирует «Доспех веры» и вступает в бой, ощущая, как сила веры усиливает его удары.	{}	2025-12-25 20:48:27.413999+03	18
304	user	Георг: Я резко поворачиваюсь на крик, уже поднимая оружие.\n— Там, — говорю я твёрдо. — Если это снова налёт — мы встретим их первыми.\nЯ делаю шаг вперёд, чувствуя, как тишина перед бурей сгущается вокруг нас.	{}	2025-12-25 20:56:37.103367+03	18
305	ai	Из тёмного переулка появляются серые дворфы, их оружие зловеще поблескивает в свете факелов. Георг даёт знак, и ополченцы мгновенно выстраиваются в оборонительную линию. Эми создаёт «Щит мага» над группой, а Бивил с рёвом бросается навстречу врагам. Георг активирует «Благословение оружия» и вступает в бой, ощущая, как сила веры укрепляет его решимость.	{}	2025-12-25 20:56:39.322132+03	18
314	user	Георг: Я поднимаю голос, перекрывая звон стали.\n— Разбиться на тройки! Удар — отход — снова удар! Не стойте на месте!\n\nЯ ловлю взгляд Эми и коротко киваю, затем шагаю за Бивилом, прикрывая его спину.\n— Мы продавим их, — говорю я себе и иду вперёд, не давая усталости взять верх.	{}	2025-12-25 21:00:43.124624+03	18
211	ai	Серые дворфы, ошеломлённые атакой Тармаса, на мгновение растерялись, но быстро оправились и попытались организовать контратаку. Георг, заметив это, приказал ополченцам усилить давление в центре. Бивил, пробиваясь сквозь ряды врагов, расчищал путь для товарищей. Эми направила «Волшебную стрелу» в сторону вражеского командира, пытаясь ослабить руководство нападающих. Битва продолжалась, но перевес постепенно смещался в сторону защитников Западной Гавани.	{}	2025-12-24 06:20:42.554563+03	16
218	ai	В этот момент в небе вспыхнул яркий луч света — Тармас направил «Свет», чтобы дезориентировать гитиянку и нарушить её магические плетения. Георг, уловив шанс, крикнул ополченцам: «Вперёд! Не дайте ей опомниться!» Союзники усилили натиск, тесня врагов. Гитиянка на мгновение растерялась, и её заклинание распалось в воздухе.	{}	2025-12-24 06:21:02.663509+03	16
225	ai	После нескольких часов поисков осколок так и не найден. Георг, Эми и Бивил возвращаются к дому старейшины, где их ждёт Тармас. Эльф-волшебник сообщает, что поблизости врагов нет, но не исключает, что они могут вернуться. Обсуждают план укрепления обороны: Георг предлагает усилить ополчение, Эми — установить магические ловушки, а Бивил — укрепить защитные сооружения у моста.	{}	2025-12-24 06:21:23.734255+03	16
232	ai	Атака становилась всё яростнее, но защитники Западной Гавани стояли твёрдо. Георг заметил, что гитиянка снова начала плести сложное заклинание, и предупредил союзников. Эми удвоила усилия, поддерживая «Щит мага», а Тармас приготовился к новой магической атаке. Бивил, несмотря на усталость, продолжал вдохновлять ополченцев, бросая их в контратаки и не давая врагу закрепиться.	{}	2025-12-24 06:21:49.266452+03	16
264	ai	Дни шли за днями, и жизнь в Западной Гавани постепенно входила в мирное русло, хотя бдительность не ослабевала. Георг, Эми, Бивил и Тармас регулярно проводили совещания, обсуждая меры безопасности и возможные угрозы. В селе начали восстанавливать повреждённые дома, а жители, чувствуя поддержку лидеров, всё больше верили в свои силы и в то, что смогут защитить свой дом от любых напастей.	{}	2025-12-24 06:34:48.849555+03	16
270	ai	Тармас провёл всю ночь, исследуя магические колебания, и утром вернулся с тревожными новостями: источник колебаний — мощный артефакт, скрытый где-то поблизости. Георг предложил объединить усилия и организовать поисковую экспедицию. Эми вызвалась помочь с магическим сканированием местности, а Бивил собрал группу ополченцев для защиты во время поисков. Жители села с волнением следили за приготовлениями.	{}	2025-12-24 06:41:16.773112+03	16
276	ai	Георг, Эми, Бивил и Тармас отправились на поиски артефакта, взяв с собой несколько надёжных ополченцев. Эми использовала заклинания для магического сканирования местности, а Тармас внимательно следил за изменениями в магическом фоне. Георг и Бивил внимательно осматривали окрестности, стараясь не упустить ничего подозрительного. Напряжение висело в воздухе — все понимали, что находка может изменить ход событий.	{}	2025-12-24 06:45:43.75297+03	16
294	user	Георг: Я делаю шаг вперёд, поднимая оружие, и холодно встречаю их рывок.\n— За Гавань! — вырывается у меня, когда вера становится щитом и сталью одновременно.\nЯ встаю между врагами и друзьями, принимая удар на себя и отвечая без колебаний.	{}	2025-12-25 20:49:49.68211+03	18
295	ai	Блейдлинги наседают, но Георг, окутанный сиянием Доспеха веры, стойко держит удар. Его меч сверкает в темноте, отражая атаки. Бивил умело прикрывает друга, нанося точные удары, а Эми поддерживает их, посылая магические импульсы в сторону врагов. Постепенно преимущество переходит на сторону героев, но вдруг из-за домов появляются новые силуэты…	{}	2025-12-25 20:49:51.368804+03	18
306	user	Георг: Я выхожу на шаг вперёд, становясь плечом к плечу с ополченцами.\n— Держим строй, — бросаю я спокойно, и меч в моей руке вспыхивает благословением.\n— За Западную Гавань. Ни шагу назад.	{}	2025-12-25 20:57:25.68605+03	18
307	ai	Серые дворфы наступают, но ополченцы стоят твёрдо, следуя приказу Георга. Бивил рубит врагов с неистовой силой, а Эми поддерживает товарищей магией, посылая вспышки света в самую гущу сражения. Георг чувствует, как с каждым мгновением его связь с силой веры становится крепче, и его удары становятся всё точнее и мощнее. Внезапно из темноты появляется новый отряд захватчиков…	{}	2025-12-25 20:57:27.496238+03	18
212	ai	Внезапно из-за домов появилась таинственная женщина-гитиянка — глава вторжения. Она начала плести сложные магические узоры, и в воздухе зазвучали зловещие нотки. Георг понял: если не остановить её, победа будет потеряна. Он приказал Бивилу и нескольким бойцам отвлечь её, а сам вместе с Эми стал искать способ нейтрализовать магическую угрозу.	{}	2025-12-24 06:20:45.209229+03	16
219	ai	Гитиянка, потеряв концентрацию, отступила на несколько шагов. Ополченцы, воодушевлённые успехом, с удвоенной энергией ринулись вперёд. Бивил пробивался к центру вражеских рядов, Эми поддерживала «Щит мага» и готовилась к новым атакам, а Георг возносил молитвы, усиливая дух товарищей. Серые дворфы и блейдлинги начали отступать, понимая, что преимущество перешло к защитникам Западной Гавани.	{}	2025-12-24 06:21:05.794236+03	16
226	ai	Георг приступает к тренировке ополченцев, уделяя особое внимание боевому строю и взаимодействию в группе. Эми начинает создавать магические ловушки, размещая их в ключевых точках села. Бивил организует работы по укреплению моста и близлежащих оборонительных сооружений. Жители, вдохновлённые лидерством молодых героев, активно включаются в подготовку к возможной новой угрозе.	{}	2025-12-24 06:21:28.430821+03	16
200	system	- Вставай! Вставай! На нас напали! - пробивается сквозь сон встревоженный голос.\n- Бивил? - бормочет Георг.\n- Вставай, Западная Гавань атакована!\nГеорг резко открывает глаза и садится. \nПрямо перед ним (ней) стоят друзья: Бивил и Эми. Они тяжело дышат, но в их глазах облегчение - они оказались быстрее вторженцев.	{}	2025-12-24 06:20:08.657754+03	16
201	ai	— Что происходит? — спрашивает Георг, вскакивая с кровати и хватаясь за оружие.\n— Не знаем, — отвечает Бивил, — но блейдлинги и серые дворфы уже в селе. Они рыщут по домам и атакуют людей.\n— Нужно собрать ополчение, — решительно говорит Эми. — Георг, ты сможешь объединить людей и организовать сопротивление?\nГеорг кивает и выбегает из дома, крича, чтобы все собирались у моста.	{}	2025-12-24 06:20:11.375188+03	16
202	ai	Георг мчится по улицам Западной Гавани, выкрикивая призывы к сбору ополчения. Люди, напуганные и растерянные, постепенно собираются у моста. Некоторые уже вооружились вилами и топорами. Георг видит, как в дальнем конце села мелькают тени блейдлингов, и понимает — времени мало. Он начинает раздавать указания, организуя людей в небольшие группы для защиты села.	{}	2025-12-24 06:20:14.418579+03	16
203	ai	Эми и Бивил присоединяются к Георгу у моста. Эми создаёт «Щит мага», чтобы защитить собравшихся от внезапной магической атаки, а Бивил помогает Георгу распределять людей по группам. В это время издалека слышны крики и звон оружия — блейдлинги и серые дворфы уже близко. Георг чувствует, как напряжение нарастает, и понимает, что каждая секунда на счету.	{}	2025-12-24 06:20:18.855631+03	16
204	ai	Георг применяет «Благословение оружия», усиливая оружие ополченцев. Бивил, используя свой опыт, обучает нескольких добровольцев основам боевого строя. Эми поддерживает «Щит мага» и готовится использовать «Свет», чтобы осветить тёмные углы села и обнаружить скрытых врагов. Вдруг из-за домов появляется группа блейдлингов — пора вступать в бой.	{}	2025-12-24 06:20:22.234156+03	16
205	ai	Георг поднимает руку, давая сигнал к атаке. Ополченцы, воодушевлённые его решимостью и усиленные «Благословением оружия», бросаются на блейдлингов. Бивил ведёт вперёд небольшую группу, умело руководя их действиями. Эми направляет «Свет» прямо на врагов, ослепляя их и помогая товарищам разглядеть противника. Первый удар даётся тяжело, но дух сопротивления крепнет с каждой минутой.	{}	2025-12-24 06:20:25.152762+03	16
233	ai	Гитиянка завершила плетение заклинания, и в воздухе вспыхнул яркий луч, направленный в сторону моста. Эми с трудом удерживала «Щит мага», чувствуя, как магия истощает её силы. Георг, увидев опасность, вознёс молитву, усиливая защиту союзников. Тармас, сосредоточившись, послал мощный «Огненный шар» прямо в гитиянку, пытаясь прервать её магические действия. Ополченцы, вдохновлённые лидерами, с новой силой ринулись в атаку.	{}	2025-12-24 06:21:53.150504+03	16
311	ai	Захватчики пытаются прорваться, но слаженные действия Георга, Бивила, Эми и ополченцев не дают им шанса. Георг чувствует, как каждый его удар подпитывается силой веры, а защита становится непроницаемой. В воздухе висит грохот металла и крики битвы. Где-то вдалеке слышится топот — похоже, что приближается ещё один отряд врагов. Георг на мгновение замирает, оценивая ситуацию.	{}	2025-12-25 20:58:41.122268+03	18
313	ai	Георг видит, как Бивил и Эми начинают уставать, и понимает — нужно изменить тактику. Он кричит ополченцам, чтобы те перегруппировались и создали несколько мобильных отрядов для контратак. Эми кивает, соглашаясь с планом, и начинает готовить новые заклинания, а Бивил, несмотря на усталость, вновь бросается в бой, расчищая путь для манёвра.	{}	2025-12-25 20:59:17.198712+03	18
315	ai	Ополченцы перегруппировываются, образуя мобильные тройки, и начинают совершать быстрые контратаки. Георг чувствует, как ритм боя меняется — теперь инициатива в их руках. Эми посылает магические импульсы, поддерживая союзников, а Бивил с яростью рубит врагов. Но вдруг из-за домов появляется фигура волшебника — Тармаса.	{}	2025-12-25 21:00:45.068495+03	18
322	user	Георг: Я на мгновение замираю, вглядываясь в силуэт, и напряжение чуть отпускает.\n\n— Тармас… — выдыхаю я с облегчением.\nЯ поднимаю клинок, но уже не для удара, а в знак внимания. — Хорошо, что ты здесь. Нам нужна магия на флангах — они ещё лезут из переулков.	{}	2025-12-25 21:08:00.680521+03	18
323	ai	Тармас кивает в ответ и поднимает руки, начиная плести сложное заклинание. Воздух вокруг него мерцает, и вскоре над селом вспыхивает яркий свет — это «Свет» в исполнении опытного волшебника. Теперь переулки и тёмные углы становятся видны как на ладони, лишая врагов возможности скрываться. Ополченцы воодушевляются и с новыми силами бросаются в бой.	{}	2025-12-25 21:08:02.884199+03	18
324	user	Георг: Я прищуриваюсь от вспышки, а затем чувствую, как уверенность возвращается в ряды.\n— Вот так, — говорю я глухо, поднимая меч. — Теперь им негде прятаться.\nЯ делаю шаг вперёд вместе с ополченцами, готовый дожать врага при свете.	{}	2025-12-25 21:10:58.850106+03	18
325	ai	Захватчики теряют преимущество, их атаки становятся хаотичными и менее скоординированными. Георг видит, как несколько врагов пытаются скрыться в одном из переулков, и даёт знак мобильным отрядам преследовать их. Эми продолжает поддерживать союзников магией, а Бивил яростно атакует тех, кто осмеливается противостоять. В воздухе витает запах победы, но Георг не расслабляется — он знает, что битва ещё не окончена.	{}	2025-12-25 21:11:02.717247+03	18
326	user	Георг: Я поднимаю руку и резко указываю в сторону переулка.\n— Не дайте им уйти. Давите до конца, — приказываю я.\nСам же остаюсь в строю, всматриваясь в освещённые улицы: победа близко, но пока враг дышит — я не опускаю меч.	{}	2025-12-25 21:11:35.49034+03	18
327	ai	Захватчики, лишившиеся возможности скрываться, начинают отступать. Георг чувствует, как напряжение постепенно сходит на нет, но всё равно внимательно следит за округой. Вдруг он замечает движение в одном из домов — возможно, там ещё остались враги. Он даёт знак Бивилу и Эми проверить здание, а сам продолжает осматривать улицы, готовый к любым неожиданностям.	{}	2025-12-25 21:11:38.723105+03	18
328	ai	Бивил и Эми осторожно подходят к дому, откуда было замечено движение. Георг остаётся на улице, напряжённо вслушиваясь в звуки ночи и держа меч наготове. Внезапно из тёмного переулка доносится шёпот — кто-то пытается подобраться незамеченным. Георг резко оборачивается, готовый отразить новую атаку.	{}	2025-12-25 21:12:15.355859+03	18
329	ai	Георг всматривается в темноту переулка, пытаясь уловить малейший шорох. В воздухе витает напряжение — он чувствует, что враг не оставил надежд на победу. Вдруг из-за угла появляется силуэт гитиянки. Её глаза сверкают в темноте, а в руках мерцает магическая энергия.\n\n— Она командует вторжением, — проносится в голове Георга. — Нужно остановить её.	{}	2025-12-25 21:12:28.171962+03	18
330	ai	Георг мгновенно активирует «Доспех веры», ощущая, как сила наполняет его. Он поднимает меч и шаг за шагом продвигается к гитиянке, внимательно следя за её движениями. В голове мелькает мысль: «Если удастся обезвредить её, остальные враги потеряют координацию». Георг готовится к решающей схватке, сердце бьётся в унисон с ритмом битвы.	{}	2025-12-25 21:12:42.451375+03	18
357	user	Георг: Я делаю шаг вперёд, не сводя с неё взгляда.\n— Держать строй, — бросаю я ополченцам.\n\nЯ поднимаю клинок и встаю между гитиянкой и людьми.\nЕсли удар придётся принять — значит, он будет на меня.	{}	2025-12-25 21:40:07.636686+03	18
358	ai	Гитиянка холодно улыбается и делает пасс рукой — в сторону Георга летит сгусток магической энергии. Он парирует атаку, благодаря «Доспеху веры», и отвечает стремительным выпадом меча. Битва разворачивается в смертельном танце: магия сталкивается с силой веры, и каждый удар отдаётся эхом в ночной тишине. Георг чувствует, как с каждым мгновением его решимость крепнет, а воля к победе горит ярче.	{}	2025-12-25 21:40:12.418799+03	18
359	user	Георг: Я принимаю удар на себя и тут же иду вперёд, не давая ей отступить.\n— Хватит, — выдыхаю я сквозь зубы и снова бью, вкладывая в движение всю волю.\n\nПока я стою перед ней, людям за моей спиной ничто не угрожает.	{}	2025-12-25 21:40:29.386088+03	18
360	ai	Гитиянка отступает на шаг, но тут же контратакует, запуская в Георга серию магических импульсов. Он с трудом отражает атаки, чувствуя, как «Доспех веры» дрожит под натиском чужой силы. В воздухе раздаётся треск, земля под ногами начинает дрожать — битва достигает кульминации. Георг собирает всю свою волю и готовится к решающему удару.	{}	2025-12-25 21:40:32.713775+03	18
361	user	Георг: Я сжимаю зубы и делаю последний шаг вперёд, игнорируя дрожь под ногами.\n— Не сегодня, — бросаю я и поднимаю клинок для удара.\n\nЯ вкладываю в него всё, что у меня есть — веру, ярость и решимость не отступить.	{}	2025-12-25 21:40:56.399553+03	18
362	ai	Клинок Георга сверкает в воздухе, устремляясь к гитиянке. Она пытается выставить защиту, но сила веры и решимость героя оказываются мощнее. Магическая защита трескается, и удар достигает цели. Гитиянка отшатывается, её глаза полны удивления и боли. Георг чувствует, как победа становится ближе, и готов нанести последний удар.	{}	2025-12-25 21:41:01.36801+03	18
363	user	Георг: Я не отвожу клинок и не даю ей ни шага.\nМысли о пощаде даже не успевают оформиться — за моей спиной люди, и я знаю цену промедления.\n\n— За Гавань, — говорю я глухо.\n\nЯ делаю шаг вперёд и довожу удар до конца, вкладывая в него всё, что во мне есть.\nЗло не отступает само — его останавливают.	{}	2025-12-25 21:43:26.282523+03	18
364	ai	Гитиянка падает на землю, её магическая энергия угасает. Георг стоит над ней, тяжело дыша и не опуская меча. Вокруг стихает грохот битвы — остальные враги, лишившись своего командира, начинают отступать. Ополченцы радостно кричат, чувствуя вкус победы. Георг оглядывается на село, понимая, что Западная Гавань выстояла.	{}	2025-12-25 21:43:31.023677+03	18
365	ai	Георг опускает меч и медленно оборачивается к своим товарищам. Бивил и Эми подходят к нему, их лица светятся от облегчения и радости. Ополченцы собираются вокруг, шумно обсуждая битву и прославляя героев. Георг чувствует усталость, но в его сердце теплится гордость за то, что они смогли защитить Западную Гавань. Он знает — впереди ещё много испытаний, но сейчас можно ненадолго вздохнуть с облегчением.	{}	2025-12-25 21:43:47.848421+03	18
366	ai	Георг подходит к ополченцам и поднимает руку, призывая к тишине.\n— Мы отстояли Гавань, — говорит он твёрдо, — но нельзя терять бдительности. Нужно проверить село, убедиться, что все враги изгнаны, а пострадавшим оказать помощь.\nЛюди кивают и начинают расходиться по улицам, а Бивил и Эми остаются рядом с Георгом, готовые к новым заданиям.	{}	2025-12-25 21:44:04.037513+03	18
367	ai	Георг вместе с Бивилом и Эми обходит улицы Западной Гавани, проверяя дома и помогая пострадавшим. В воздухе ещё витает запах дыма и металла, но теперь слышны и другие звуки — голоса людей, обсуждающих битву, и детский плач. В одном из домов они находят семью, укрывшуюся от опасности, и успокаивают их, обещая, что теперь всё будет хорошо.	{}	2025-12-25 21:44:14.794209+03	18
368	ai	Георг, Бивил и Эми продолжают обход села. В одном из огородов они находят брошенное вражеское оружие, а в заброшенном амбаре — несколько раненых врагов. Георг, после короткого раздумья, приказывает оказать помощь и им. Пока Бивил занимается раненными, Эми осматривает окрестности, проверяя, не осталось ли где засад.	{}	2025-12-25 21:44:28.233836+03	18
369	ai	Георг осматривает окрестности и замечает разрушенные ограды и разбитые окна — следы ожесточённой битвы. Он чувствует тяжесть в сердце, осознавая, сколько труда потребуется для восстановления села. Вдруг из-за угла появляется Георгий Редфелл с группой ополченцев — они сообщают о нескольких неповреждённых складах с продовольствием и предлагают начать с организации помощи наиболее пострадавшим семьям.	{}	2025-12-25 21:44:46.121835+03	18
\.


--
-- Data for Name: adventures_adventurememory; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.adventures_adventurememory (id, kind, title, content, importance, tags, created_at, updated_at, adventure_id) FROM stdin;
\.


--
-- Data for Name: adventures_character; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.adventures_character (id, is_player, title, age, body_power, mind_power, will_power, description, tags, created_at, updated_at, adventure_id, location_id, race_id, in_party, body_power_progress, mind_power_progress, will_power_progress) FROM stdin;
1	t	Эми Фарн	17	7	18	16	Ученица волшебника Тармаса и подруга главного героя. Добрая девушка, любящая книги и считающая, что знания позволят сделать мир лучше.	{Эми,Фарн}	2025-12-23 15:00:02.93752+03	2025-12-23 23:13:26.603053+03	1	1	1	t	0	0	0
3	f	Тармас	241	10	30	20	Эльф-волшебник	{Тармас,Тармасу,Тармосе,Тармаса}	2025-12-23 15:16:49.086694+03	2025-12-23 17:40:18.443064+03	1	1	3	f	0	0	0
4	f	Глава вторжения	90	12	28	20	Таинственная женщина гитиянки, командующая вторжением	{}	2025-12-23 17:42:48.056324+03	2025-12-23 20:57:59.454917+03	1	1	4	f	0	0	0
75	f	Глава вторжения	90	12	28	20	Таинственная женщина гитиянки, командующая вторжением	{}	2025-12-24 06:20:08.645831+03	2025-12-24 06:20:08.645841+03	16	31	92	f	0	0	0
76	f	Тармас	241	10	30	20	Эльф-волшебник	{Тармас,Тармасу,Тармосе,Тармаса}	2025-12-24 06:20:08.646533+03	2025-12-24 06:20:08.646541+03	16	31	96	f	0	0	0
73	t	Бивил Старлинг	19	16	8	14	Друг детства главного героя. Служит в деревенском ополчении. Храбрый, комфортно чувствует себя в Западной Гавани и не думает о том, чтобы уехать из неё	{Бивил,Старлинг,Бивила,Бивилу,Бивилом,Бивиле}	2025-12-24 06:20:08.643714+03	2025-12-24 06:20:08.643724+03	16	31	95	t	10	0	0
74	f	Георг	18	16	8	14		{}	2025-12-24 06:20:08.645054+03	2025-12-24 06:20:08.645063+03	16	31	95	t	10	0	0
2	t	Бивил Старлинг	19	16	8	14	Друг детства главного героя. Служит в деревенском ополчении. Храбрый, комфортно чувствует себя в Западной Гавани и не думает о том, чтобы уехать из неё	{Бивил,Старлинг,Бивила,Бивилу,Бивилом,Бивиле}	2025-12-23 15:15:06.869461+03	2025-12-23 23:12:57.836966+03	1	1	1	t	0	0	0
77	t	Эми Фарн	17	7	18	16	Ученица волшебника Тармаса и подруга главного героя. Добрая девушка, любящая книги и считающая, что знания позволят сделать мир лучше.	{Эми,Фарн}	2025-12-24 06:20:08.64719+03	2025-12-24 06:20:08.647198+03	16	31	95	t	0	10	0
84	t	Георг	18	16	8	14		{}	2025-12-25 20:43:20.329704+03	2025-12-25 20:43:20.329707+03	18	35	107	t	10	0	10
37	t	Георг	18	16	8	14		{}	2025-12-24 00:04:45.645632+03	2025-12-24 00:05:39.373351+03	1	1	1	t	0	0	0
83	t	Бивил Старлинг	19	16	8	14	Друг детства главного героя. Служит в деревенском ополчении. Храбрый, комфортно чувствует себя в Западной Гавани и не думает о том, чтобы уехать из неё	{Бивил,Старлинг,Бивила,Бивилу,Бивилом,Бивиле}	2025-12-25 20:43:20.329262+03	2025-12-25 20:43:20.329266+03	18	35	107	t	0	0	0
85	f	Глава вторжения	90	12	28	20	Таинственная женщина гитиянки, командующая вторжением	{}	2025-12-25 20:43:20.329943+03	2025-12-25 20:43:20.329945+03	18	35	104	f	0	0	0
86	f	Тармас	241	10	30	20	Эльф-волшебник	{Тармас,Тармасу,Тармосе,Тармаса}	2025-12-25 20:43:20.330156+03	2025-12-25 20:43:20.330158+03	18	35	108	f	0	0	0
87	t	Эми Фарн	17	7	18	16	Ученица волшебника Тармаса и подруга главного героя. Добрая девушка, любящая книги и считающая, что знания позволят сделать мир лучше.	{Эми,Фарн}	2025-12-25 20:43:20.330384+03	2025-12-25 20:43:20.330386+03	18	35	107	t	0	0	0
\.


--
-- Data for Name: adventures_characterfaction; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.adventures_characterfaction (id, adventure_id, character_id, faction_id) FROM stdin;
\.


--
-- Data for Name: adventures_characterrelationship; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.adventures_characterrelationship (id, kind, description, created_at, updated_at, adventure_id, from_character_id, to_character_id) FROM stdin;
\.


--
-- Data for Name: adventures_charactersystem; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.adventures_charactersystem (id, level, notes, adventure_id, character_id, system_id, progress_percent) FROM stdin;
1	2		1	1	1	10
2	5		1	3	1	51
3	5		1	4	1	0
15	2		1	37	2	0
16	1		1	37	3	0
30	2		16	77	47	20
33	2		16	74	46	10
34	1		16	74	48	10
35	2		16	73	46	10
42	2		18	87	53	10
43	5		18	86	53	51
44	5		18	85	53	0
47	2		18	83	52	0
22	2		1	2	2	0
45	2		18	84	52	10
31	5		16	76	47	51
32	5		16	75	47	0
46	1		18	84	54	10
\.


--
-- Data for Name: adventures_charactertechnique; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.adventures_charactertechnique (id, learned_at, notes, adventure_id, character_id, technique_id) FROM stdin;
1	2025-12-23 16:47:08.515311+03		1	1	1
2	2025-12-23 17:38:40.591371+03		1	3	1
3	2025-12-23 17:43:15.369961+03		1	4	1
4	2025-12-23 21:00:13.299417+03		1	1	2
5	2025-12-23 21:00:47.439423+03		1	3	2
6	2025-12-23 21:00:59.232838+03		1	3	3
7	2025-12-23 21:10:24.354863+03		1	1	4
8	2025-12-23 21:11:00.269877+03		1	3	4
19	2025-12-24 00:05:22.682419+03		1	37	29
20	2025-12-24 00:05:28.949931+03		1	37	30
42	2025-12-24 06:20:08.65376+03		16	76	80
43	2025-12-24 06:20:08.654183+03		16	75	80
45	2025-12-24 06:20:08.654851+03		16	76	84
46	2025-12-24 06:20:08.655163+03		16	76	82
48	2025-12-24 06:20:08.655808+03		16	76	83
44	2025-12-24 06:20:08.654528+03	Эми готовится использовать заклинание «Щит мага» в случае необходимости	16	77	84
47	2025-12-24 06:20:08.655502+03	Эми использует заклинание «Свет» для освещения местности	16	77	83
49	2025-12-24 06:20:08.656068+03	Георг готов использовать «Благословение оружия» для усиления оружия ополченцев	16	74	79
50	2025-12-24 06:20:08.656318+03	Георг готов использовать «Доспех веры» для защиты в бою	16	74	81
61	2025-12-25 20:43:20.332467+03		18	87	92
62	2025-12-25 20:43:20.332724+03		18	86	92
63	2025-12-25 20:43:20.332882+03		18	85	92
64	2025-12-25 20:43:20.333014+03		18	87	96
65	2025-12-25 20:43:20.333142+03		18	86	96
66	2025-12-25 20:43:20.33326+03		18	86	94
67	2025-12-25 20:43:20.333397+03		18	87	95
68	2025-12-25 20:43:20.333512+03		18	86	95
69	2025-12-25 20:43:20.333617+03		18	84	91
70	2025-12-25 20:43:20.333718+03		18	84	93
41	2025-12-24 06:20:08.653067+03	Эми использует заклинание «Волшебная стрела» для магического сканирования местности	16	77	80
\.


--
-- Data for Name: adventures_faction; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.adventures_faction (id, title, description, tags, created_at, updated_at, adventure_id) FROM stdin;
1	Западная гавань	Жители западной гавани	{}	2025-12-23 15:24:01.65874+03	2025-12-23 15:24:01.658759+03	1
2	Вторженцы в Западную Гавань	Существа, внезапно вторгшиеся в Западную Гавань.	{}	2025-12-23 15:24:49.434658+03	2025-12-23 18:09:37.156718+03	1
31	Вторженцы в Западную Гавань	Существа, внезапно вторгшиеся в Западную Гавань.	{}	2025-12-24 06:20:08.637141+03	2025-12-24 06:20:08.637153+03	16
32	Западная гавань	Жители западной гавани	{}	2025-12-24 06:20:08.637865+03	2025-12-24 06:20:08.637875+03	16
36	Вторженцы в Западную Гавань	Существа, внезапно вторгшиеся в Западную Гавань.	{}	2025-12-25 20:43:20.327278+03	2025-12-25 20:43:20.327281+03	18
37	Западная гавань	Жители западной гавани	{}	2025-12-25 20:43:20.327467+03	2025-12-25 20:43:20.32747+03	18
\.


--
-- Data for Name: adventures_location; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.adventures_location (id, title, description, x, y, width, height, tags, created_at, updated_at, adventure_id) FROM stdin;
1	Западная Гавань	Село, в котором вырос главный герой вместе с Эми и Бивилом.\nСостоит из пятидесяти деревянных домов и прилегающих к ним огородов. Через центр села протекает ручей около трёх метров в ширину, через него перекинут деревянный мост.	500	500	10	10	{западная,гавань,деревня,гавани}	2025-12-23 14:53:23.171449+03	2025-12-23 15:43:19.476823+03	1
2	Топи	Болотистые территории, контролируемые людоящерами.\n\nПосреди топей находятся таинственные древние руины. Надземная часть давно разрушена и поглощена природой, но под землёй есть частично сохранившиеся катакомбы.	450	350	100	100	{топи}	2025-12-23 21:03:52.517946+03	2025-12-23 21:08:00.136866+03	1
31	Западная Гавань	Село, в котором вырос главный герой вместе с Эми и Бивилом.\nСостоит из пятидесяти деревянных домов и прилегающих к ним огородов. Через центр села протекает ручей около трёх метров в ширину, через него перекинут деревянный мост.	500	500	10	10	{западная,гавань,деревня,гавани}	2025-12-24 06:20:08.619279+03	2025-12-24 06:20:08.619286+03	16
32	Топи	Болотистые территории, контролируемые людоящерами.\n\nПосреди топей находятся таинственные древние руины. Надземная часть давно разрушена и поглощена природой, но под землёй есть частично сохранившиеся катакомбы.	450	350	100	100	{топи}	2025-12-24 06:20:08.619708+03	2025-12-24 06:20:08.619713+03	16
35	Западная Гавань	Село, в котором вырос главный герой вместе с Эми и Бивилом.\nСостоит из пятидесяти деревянных домов и прилегающих к ним огородов. Через центр села протекает ручей около трёх метров в ширину, через него перекинут деревянный мост.	500	500	10	10	{западная,гавань,деревня,гавани}	2025-12-25 20:43:20.32007+03	2025-12-25 20:43:20.320075+03	18
36	Топи	Болотистые территории, контролируемые людоящерами.\n\nПосреди топей находятся таинственные древние руины. Надземная часть давно разрушена и поглощена природой, но под землёй есть частично сохранившиеся катакомбы.	450	350	100	100	{топи}	2025-12-25 20:43:20.320464+03	2025-12-25 20:43:20.320469+03	18
\.


--
-- Data for Name: adventures_moderationentry; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.adventures_moderationentry (adventure_id, submitted_at) FROM stdin;
\.


--
-- Data for Name: adventures_otherinfo; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.adventures_otherinfo (id, category, title, description, tags, created_at, updated_at, adventure_id) FROM stdin;
\.


--
-- Data for Name: adventures_publishedadventure; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.adventures_publishedadventure (adventure_id, published_at) FROM stdin;
1	2025-12-25 20:00:54.425927+03
\.


--
-- Data for Name: adventures_race; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.adventures_race (id, title, description, tags, created_at, updated_at, adventure_id, life_span) FROM stdin;
2	Блэйдлинг	Гуманоиды с торчащими из тела шипами. Имеют коричневую кожу.	{блэйдлинг,блэйдлинги}	2025-12-23 15:03:56.945892+03	2025-12-23 20:56:19.433375+03	1	70
6	Людоящер	Выглядят, как прямоходящие ящеры около 2х метров ростом. Если неподалёку появляется дракон, с готовностью становятся его подчинёнными.	{людоящер,людоящера,людоящеру,людоящере,людоящером}	2025-12-23 20:50:10.792806+03	2025-12-23 20:56:33.047893+03	1	60
5	Серый дворф	Низкие гуманоиды, похожие на людей, с серой кожей	{дворфы,дворф,дворфа,дворфу}	2025-12-23 17:47:40.003203+03	2025-12-23 20:56:39.617455+03	1	320
1	Человек	Люди быстро осваивают новые знания, самая распространённая раса в мире	{человек,люди,человеческий}	2025-12-23 15:02:19.403018+03	2025-12-23 20:56:59.757263+03	1	100
3	Эльф	Выглядят, как худощавые люди с длинными ушами.	{эльф,эльфы,эльфам}	2025-12-23 15:04:47.905065+03	2025-12-23 20:57:11.516421+03	1	500
4	Гитиянки	Гуманоиды с зелёной кожей и длинными узкими ушами. Живут на астральном плане и редко бывают в обычном мире.	{}	2025-12-23 17:41:42.665139+03	2025-12-23 20:57:40.449873+03	1	200
91	Блэйдлинг	Гуманоиды с торчащими из тела шипами. Имеют коричневую кожу.	{блэйдлинг,блэйдлинги}	2025-12-24 06:20:08.620819+03	2025-12-24 06:20:08.620826+03	16	70
92	Гитиянки	Гуманоиды с зелёной кожей и длинными узкими ушами. Живут на астральном плане и редко бывают в обычном мире.	{}	2025-12-24 06:20:08.621207+03	2025-12-24 06:20:08.621212+03	16	200
93	Людоящер	Выглядят, как прямоходящие ящеры около 2х метров ростом. Если неподалёку появляется дракон, с готовностью становятся его подчинёнными.	{людоящер,людоящера,людоящеру,людоящере,людоящером}	2025-12-24 06:20:08.621518+03	2025-12-24 06:20:08.621524+03	16	60
94	Серый дворф	Низкие гуманоиды, похожие на людей, с серой кожей	{дворфы,дворф,дворфа,дворфу}	2025-12-24 06:20:08.621832+03	2025-12-24 06:20:08.621838+03	16	320
95	Человек	Люди быстро осваивают новые знания, самая распространённая раса в мире	{человек,люди,человеческий}	2025-12-24 06:20:08.622138+03	2025-12-24 06:20:08.622144+03	16	100
96	Эльф	Выглядят, как худощавые люди с длинными ушами.	{эльф,эльфы,эльфам}	2025-12-24 06:20:08.622455+03	2025-12-24 06:20:08.622461+03	16	500
103	Блэйдлинг	Гуманоиды с торчащими из тела шипами. Имеют коричневую кожу.	{блэйдлинг,блэйдлинги}	2025-12-25 20:43:20.321483+03	2025-12-25 20:43:20.321488+03	18	70
104	Гитиянки	Гуманоиды с зелёной кожей и длинными узкими ушами. Живут на астральном плане и редко бывают в обычном мире.	{}	2025-12-25 20:43:20.321767+03	2025-12-25 20:43:20.321771+03	18	200
105	Людоящер	Выглядят, как прямоходящие ящеры около 2х метров ростом. Если неподалёку появляется дракон, с готовностью становятся его подчинёнными.	{людоящер,людоящера,людоящеру,людоящере,людоящером}	2025-12-25 20:43:20.321977+03	2025-12-25 20:43:20.321983+03	18	60
106	Серый дворф	Низкие гуманоиды, похожие на людей, с серой кожей	{дворфы,дворф,дворфа,дворфу}	2025-12-25 20:43:20.322186+03	2025-12-25 20:43:20.32219+03	18	320
107	Человек	Люди быстро осваивают новые знания, самая распространённая раса в мире	{человек,люди,человеческий}	2025-12-25 20:43:20.322368+03	2025-12-25 20:43:20.322371+03	18	100
108	Эльф	Выглядят, как худощавые люди с длинными ушами.	{эльф,эльфы,эльфам}	2025-12-25 20:43:20.322541+03	2025-12-25 20:43:20.322544+03	18	500
\.


--
-- Data for Name: adventures_skillsystem; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.adventures_skillsystem (id, title, description, tags, w_body, w_mind, w_will, formula_hint, created_at, updated_at, adventure_id) FROM stdin;
1	Магия Плетения	Исходит от существующего Плетения - это особый сверхъестественный объект, при взаимодействии с которым заклинатели могут воздействовать на мир	{плетение,плетения,плетении,плетением,магия,магию,магией,магии}	0	100	30	Заклинание	2025-12-23 16:36:08.173633+03	2025-12-23 16:36:08.173642+03	1
3	Сила веры	Исходит от веры, подкреплённой волей	{}	20	30	100		2025-12-23 21:17:33.150235+03	2025-12-23 21:17:33.150254+03	1
2	Боевое мастерство	Опираясь на свои тренированные тела бойцы могут использовать боевые приёмы.\nВ отличие от многих систем, эта в гораздо меньшей степени зависит от приёмов. Улучшение уровня владения даёт всестороннее улучшение.	{бой,боя,бою}	100	20	30	Приём	2025-12-23 16:38:17.304447+03	2025-12-23 23:54:50.604575+03	1
46	Боевое мастерство	Опираясь на свои тренированные тела бойцы могут использовать боевые приёмы.\nВ отличие от многих систем, эта в гораздо меньшей степени зависит от приёмов. Улучшение уровня владения даёт всестороннее улучшение.	{бой,боя,бою}	100	20	30	Приём	2025-12-24 06:20:08.625842+03	2025-12-24 06:20:08.625852+03	16
47	Магия Плетения	Исходит от существующего Плетения - это особый сверхъестественный объект, при взаимодействии с которым заклинатели могут воздействовать на мир	{плетение,плетения,плетении,плетением,магия,магию,магией,магии}	0	100	30	Заклинание	2025-12-24 06:20:08.626446+03	2025-12-24 06:20:08.626453+03	16
48	Сила веры	Исходит от веры, подкреплённой волей	{}	20	30	100		2025-12-24 06:20:08.626944+03	2025-12-24 06:20:08.626951+03	16
52	Боевое мастерство	Опираясь на свои тренированные тела бойцы могут использовать боевые приёмы.\nВ отличие от многих систем, эта в гораздо меньшей степени зависит от приёмов. Улучшение уровня владения даёт всестороннее улучшение.	{бой,боя,бою}	100	20	30	Приём	2025-12-25 20:43:20.324118+03	2025-12-25 20:43:20.324122+03	18
53	Магия Плетения	Исходит от существующего Плетения - это особый сверхъестественный объект, при взаимодействии с которым заклинатели могут воздействовать на мир	{плетение,плетения,плетении,плетением,магия,магию,магией,магии}	0	100	30	Заклинание	2025-12-25 20:43:20.324371+03	2025-12-25 20:43:20.324374+03	18
54	Сила веры	Исходит от веры, подкреплённой волей	{}	20	30	100		2025-12-25 20:43:20.324573+03	2025-12-25 20:43:20.324576+03	18
\.


--
-- Data for Name: adventures_technique; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.adventures_technique (id, title, description, tags, difficulty, tier, required_system_level, created_at, updated_at, adventure_id, system_id) FROM stdin;
1	Волшебная стрела	Запускает <уровень владения Плетением> сияющих синих сгустков, в цель. Каждый сгусток обжигает цель.	{"волшебная стрела","волшебную стрелу"}	1	1	1	2025-12-23 16:46:36.855292+03	2025-12-23 16:46:36.855319+03	1	1
2	Щит мага	Добавляет бонус отражения против атак. Позволяет игнорировать заклинание волшебная стрела.	{"щит мага","щита мага"}	1	1	1	2025-12-23 17:44:38.552546+03	2025-12-23 17:44:38.552552+03	1	1
3	Огненный шар	Наносит огненный урон по области в радиусе нескольких метров.	{}	3	3	3	2025-12-23 20:59:55.252959+03	2025-12-23 20:59:55.252978+03	1	1
4	Свет	Создаёт небольшой светящийся сгусток	{}	0	0	0	2025-12-23 21:09:54.022094+03	2025-12-23 21:09:54.022112+03	1	1
79	Благословение оружия	Усиливает способности оружия. Особенно эффективно против злых существ	{}	1	\N	1	2025-12-24 06:20:08.628804+03	2025-12-24 06:20:08.628816+03	16	48
80	Волшебная стрела	Запускает <уровень владения Плетением> сияющих синих сгустков, в цель. Каждый сгусток обжигает цель.	{"волшебная стрела","волшебную стрелу"}	1	1	1	2025-12-24 06:20:08.630974+03	2025-12-24 06:20:08.630992+03	16	47
29	Благословение оружия	Усиливает способности оружия. Особенно эффективно против злых существ	{}	1	\N	1	2025-12-23 23:56:23.277961+03	2025-12-23 23:56:23.277983+03	1	3
30	Доспех веры	Вера позволяет игнорировать получаемый урон. Чем сильнее воля и выше владение системой веры, тем больший урон в абсолютных числах игнорируется.	{}	1	\N	1	2025-12-23 23:57:56.566991+03	2025-12-23 23:57:56.567008+03	1	3
81	Доспех веры	Вера позволяет игнорировать получаемый урон. Чем сильнее воля и выше владение системой веры, тем больший урон в абсолютных числах игнорируется.	{}	1	\N	1	2025-12-24 06:20:08.631929+03	2025-12-24 06:20:08.631941+03	16	48
82	Огненный шар	Наносит огненный урон по области в радиусе нескольких метров.	{}	3	3	3	2025-12-24 06:20:08.633054+03	2025-12-24 06:20:08.633072+03	16	47
83	Свет	Создаёт небольшой светящийся сгусток	{}	0	0	0	2025-12-24 06:20:08.634004+03	2025-12-24 06:20:08.634018+03	16	47
84	Щит мага	Добавляет бонус отражения против атак. Позволяет игнорировать заклинание волшебная стрела.	{"щит мага","щита мага"}	1	1	1	2025-12-24 06:20:08.634756+03	2025-12-24 06:20:08.634768+03	16	47
91	Благословение оружия	Усиливает способности оружия. Особенно эффективно против злых существ	{}	1	\N	1	2025-12-25 20:43:20.325324+03	2025-12-25 20:43:20.325332+03	18	54
92	Волшебная стрела	Запускает <уровень владения Плетением> сияющих синих сгустков, в цель. Каждый сгусток обжигает цель.	{"волшебная стрела","волшебную стрелу"}	1	1	1	2025-12-25 20:43:20.325997+03	2025-12-25 20:43:20.326+03	18	53
93	Доспех веры	Вера позволяет игнорировать получаемый урон. Чем сильнее воля и выше владение системой веры, тем больший урон в абсолютных числах игнорируется.	{}	1	\N	1	2025-12-25 20:43:20.326212+03	2025-12-25 20:43:20.326214+03	18	54
94	Огненный шар	Наносит огненный урон по области в радиусе нескольких метров.	{}	3	3	3	2025-12-25 20:43:20.326382+03	2025-12-25 20:43:20.326385+03	18	53
95	Свет	Создаёт небольшой светящийся сгусток	{}	0	0	0	2025-12-25 20:43:20.326539+03	2025-12-25 20:43:20.326541+03	18	53
96	Щит мага	Добавляет бонус отражения против атак. Позволяет игнорировать заклинание волшебная стрела.	{"щит мага","щита мага"}	1	1	1	2025-12-25 20:43:20.326694+03	2025-12-25 20:43:20.326696+03	18	53
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	3	add_permission
6	Can change permission	3	change_permission
7	Can delete permission	3	delete_permission
8	Can view permission	3	view_permission
9	Can add group	2	add_group
10	Can change group	2	change_group
11	Can delete group	2	delete_group
12	Can view group	2	view_group
13	Can add content type	4	add_contenttype
14	Can change content type	4	change_contenttype
15	Can delete content type	4	delete_contenttype
16	Can view content type	4	view_contenttype
17	Can add session	5	add_session
18	Can change session	5	change_session
19	Can delete session	5	delete_session
20	Can view session	5	view_session
21	Can add Token	6	add_token
22	Can change Token	6	change_token
23	Can delete Token	6	delete_token
24	Can view Token	6	view_token
25	Can add Token	7	add_tokenproxy
26	Can change Token	7	change_tokenproxy
27	Can delete Token	7	delete_tokenproxy
28	Can view Token	7	view_tokenproxy
29	Can add user	8	add_user
30	Can change user	8	change_user
31	Can delete user	8	delete_user
32	Can view user	8	view_user
33	Can add character relationship	16	add_characterrelationship
34	Can change character relationship	16	change_characterrelationship
35	Can delete character relationship	16	delete_characterrelationship
36	Can view character relationship	16	view_characterrelationship
37	Can add ability	9	add_ability
38	Can change ability	9	change_ability
39	Can delete ability	9	delete_ability
40	Can view ability	9	view_ability
41	Can add adventure	10	add_adventure
42	Can change adventure	10	change_adventure
43	Can delete adventure	10	delete_adventure
44	Can view adventure	10	view_adventure
45	Can add character	13	add_character
46	Can change character	13	change_character
47	Can delete character	13	delete_character
48	Can view character	13	view_character
49	Can add character ability	14	add_characterability
50	Can change character ability	14	change_characterability
51	Can delete character ability	14	delete_characterability
52	Can view character ability	14	view_characterability
53	Can add location	18	add_location
54	Can change location	18	change_location
55	Can delete location	18	delete_location
56	Can view location	18	view_location
57	Can add adventure memory	12	add_adventurememory
58	Can change adventure memory	12	change_adventurememory
59	Can delete adventure memory	12	delete_adventurememory
60	Can view adventure memory	12	view_adventurememory
61	Can add faction	17	add_faction
62	Can change faction	17	change_faction
63	Can delete faction	17	delete_faction
64	Can view faction	17	view_faction
65	Can add character faction	15	add_characterfaction
66	Can change character faction	15	change_characterfaction
67	Can delete character faction	15	delete_characterfaction
68	Can view character faction	15	view_characterfaction
69	Can add adventure history	11	add_adventurehistory
70	Can change adventure history	11	change_adventurehistory
71	Can delete adventure history	11	delete_adventurehistory
72	Can view adventure history	11	view_adventurehistory
73	Can add race	20	add_race
74	Can change race	20	change_race
75	Can delete race	20	delete_race
76	Can view race	20	view_race
77	Can add race ability	21	add_raceability
78	Can change race ability	21	change_raceability
79	Can delete race ability	21	delete_raceability
80	Can view race ability	21	view_raceability
81	Can add other info	19	add_otherinfo
82	Can change other info	19	change_otherinfo
83	Can delete other info	19	delete_otherinfo
84	Can view other info	19	view_otherinfo
85	Can add technique	25	add_technique
86	Can change technique	25	change_technique
87	Can delete technique	25	delete_technique
88	Can view technique	25	view_technique
89	Can add character technique	23	add_charactertechnique
90	Can change character technique	23	change_charactertechnique
91	Can delete character technique	23	delete_charactertechnique
92	Can view character technique	23	view_charactertechnique
93	Can add character system	22	add_charactersystem
94	Can change character system	22	change_charactersystem
95	Can delete character system	22	delete_charactersystem
96	Can view character system	22	view_charactersystem
97	Can add skill system	24	add_skillsystem
98	Can change skill system	24	change_skillsystem
99	Can delete skill system	24	delete_skillsystem
100	Can view skill system	24	view_skillsystem
101	Can add adventure event	26	add_adventureevent
102	Can change adventure event	26	change_adventureevent
103	Can delete adventure event	26	delete_adventureevent
104	Can view adventure event	26	view_adventureevent
105	Can add adventure hero setup	27	add_adventureherosetup
106	Can change adventure hero setup	27	change_adventureherosetup
107	Can delete adventure hero setup	27	delete_adventureherosetup
108	Can view adventure hero setup	27	view_adventureherosetup
109	Can add administrator	28	add_administrator
110	Can change administrator	28	change_administrator
111	Can delete administrator	28	delete_administrator
112	Can view administrator	28	view_administrator
113	Can add moderation entry	29	add_moderationentry
114	Can change moderation entry	29	change_moderationentry
115	Can delete moderation entry	29	delete_moderationentry
116	Can view moderation entry	29	view_moderationentry
117	Can add published adventure	30	add_publishedadventure
118	Can change published adventure	30	change_publishedadventure
119	Can delete published adventure	30	delete_publishedadventure
120	Can view published adventure	30	view_publishedadventure
\.


--
-- Data for Name: authtoken_token; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.authtoken_token (key, created, user_id) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2025-12-25 19:10:04.557628+03	1	stack_10 (level 10)	2	[{"changed": {"fields": ["Level"]}}]	28	1
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	group
3	auth	permission
4	contenttypes	contenttype
5	sessions	session
6	authtoken	token
7	authtoken	tokenproxy
8	users	user
9	adventures	ability
10	adventures	adventure
11	adventures	adventurehistory
12	adventures	adventurememory
13	adventures	character
14	adventures	characterability
15	adventures	characterfaction
16	adventures	characterrelationship
17	adventures	faction
18	adventures	location
19	adventures	otherinfo
20	adventures	race
21	adventures	raceability
22	adventures	charactersystem
23	adventures	charactertechnique
24	adventures	skillsystem
25	adventures	technique
26	adventures	adventureevent
27	adventures	adventureherosetup
28	users	administrator
29	adventures	moderationentry
30	adventures	publishedadventure
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2025-12-09 22:32:01.612395+03
2	contenttypes	0002_remove_content_type_name	2025-12-09 22:35:34.914886+03
3	auth	0001_initial	2025-12-09 22:35:34.94644+03
4	auth	0002_alter_permission_name_max_length	2025-12-09 22:35:34.951324+03
5	auth	0003_alter_user_email_max_length	2025-12-09 22:35:34.955589+03
6	auth	0004_alter_user_username_opts	2025-12-09 22:35:34.958023+03
7	auth	0005_alter_user_last_login_null	2025-12-09 22:35:34.960036+03
8	auth	0006_require_contenttypes_0002	2025-12-09 22:35:34.960576+03
9	auth	0007_alter_validators_add_error_messages	2025-12-09 22:35:34.962482+03
10	auth	0008_alter_user_username_max_length	2025-12-09 22:35:34.964563+03
11	auth	0009_alter_user_last_name_max_length	2025-12-09 22:35:34.966652+03
12	auth	0010_alter_group_name_max_length	2025-12-09 22:35:34.968868+03
13	auth	0011_update_proxy_permissions	2025-12-09 22:35:34.970874+03
14	auth	0012_alter_user_first_name_max_length	2025-12-09 22:35:34.972974+03
15	users	0001_initial	2025-12-09 22:35:34.99244+03
16	admin	0001_initial	2025-12-09 22:35:35.001923+03
17	admin	0002_logentry_remove_auto_add	2025-12-09 22:35:35.005613+03
18	admin	0003_logentry_add_action_flag_choices	2025-12-09 22:35:35.008337+03
19	authtoken	0001_initial	2025-12-09 22:35:35.015651+03
20	authtoken	0002_auto_20160226_1747	2025-12-09 22:35:35.025161+03
21	authtoken	0003_tokenproxy	2025-12-09 22:35:35.026198+03
22	authtoken	0004_alter_tokenproxy_options	2025-12-09 22:35:35.027938+03
23	sessions	0001_initial	2025-12-09 22:35:35.034529+03
24	adventures	0001_initial	2025-12-23 03:40:06.34594+03
25	adventures	0002_consistency_triggers	2025-12-23 03:40:06.355212+03
26	adventures	0003_skill_systems	2025-12-23 16:32:30.120696+03
27	adventures	0004_technique_rank_optional	2025-12-23 17:01:50.916182+03
28	adventures	0005_character_system_progress	2025-12-23 17:37:13.587138+03
29	adventures	0006_adventure_events	2025-12-23 20:15:50.946081+03
30	adventures	0007_event_state_cleanup	2025-12-23 20:25:57.259724+03
31	adventures	0008_adventure_primary_hero	2025-12-23 20:46:36.848578+03
32	adventures	0009_race_life_span	2025-12-23 20:55:30.914335+03
33	users	0002_user_is_admin	2025-12-23 21:21:49.60982+03
34	adventures	0010_adventure_hero_setup	2025-12-23 22:43:27.034544+03
35	adventures	0011_adventure_hero_setup_defaults	2025-12-23 22:43:27.105792+03
36	adventures	0012_adventure_hero_setup_default_location	2025-12-23 22:56:08.654956+03
37	adventures	0013_character_in_party	2025-12-23 23:12:21.241418+03
38	adventures	0014_adventure_is_waiting_ai	2025-12-24 00:15:19.016738+03
39	adventures	0015_adventure_rollback_min_history	2025-12-24 00:36:47.465207+03
40	adventures	0016_character_stat_progress	2025-12-24 06:06:57.194503+03
41	users	0003_administrator_model	2025-12-25 18:59:42.096974+03
42	adventures	0017_moderation_publication	2025-12-25 19:58:06.674302+03
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
v87da9m2a8zohytn75pfr22vi3zg1xdc	.eJxVjEEOwiAUBe_C2hA-lJa6dO8ZCPBfpWogKe3KeHdt0oVu38y8l_BhW7PfGhY_szgLEqffLYb0QNkB30O5VZlqWZc5yl2RB23yWhnPy-H-HeTQ8rcGMfPgEMlBTyoarUdLo7H9FAhGJcMMUp0Gp6R6k5wdQB1C1AREK94f9Q84eQ:1vYntJ:KK7HItjttQSuW1_FG82ilmCcZKQewLGUsa-ZzXCq5MM	2026-01-08 19:08:41.695486+03
\.


--
-- Data for Name: users_administrator; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.users_administrator (id, level, user_id) FROM stdin;
1	10	2
2	1	3
\.


--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.users_user (id, password, last_login, is_superuser, username, first_name, last_name, is_staff, is_active, date_joined, email, credits) FROM stdin;
2	pbkdf2_sha256$1200000$m2tctJJzsf2N82hwG2zT6D$Tx/ZthszxzWHebXelLKBYGtz5ZfJWqdyJ4cKljgxNDM=	\N	f	stack_10			f	t	2025-12-09 22:43:22.347094+03	stack_10@east.west	0
1	pbkdf2_sha256$1200000$xyqaO87Hyot3TgV3cnHJbU$J0nkOTzfygyM8lrvFew/Oz08HQvG7+GgrE1GmzXwsyg=	2025-12-25 19:08:41.694351+03	t	noxlight7			t	t	2025-12-09 22:38:44.904215+03	noxlight@mail.ru	0
3	pbkdf2_sha256$1200000$I0CUt22aPcli60sDfIEsEY$/nz1nc9GaUR+zjkneywPAwghy2rg4W/CMoY3aE1TShA=	\N	f	go123			f	t	2025-12-25 19:11:51.089767+03	go123@go.go	0
\.


--
-- Data for Name: users_user_groups; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.users_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: users_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.users_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: adventures_adventure_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.adventures_adventure_id_seq', 18, true);


--
-- Name: adventures_adventureevent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.adventures_adventureevent_id_seq', 18, true);


--
-- Name: adventures_adventureherosetup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.adventures_adventureherosetup_id_seq', 17, true);


--
-- Name: adventures_adventurehistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.adventures_adventurehistory_id_seq', 369, true);


--
-- Name: adventures_adventurememory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.adventures_adventurememory_id_seq', 1, false);


--
-- Name: adventures_character_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.adventures_character_id_seq', 87, true);


--
-- Name: adventures_characterfaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.adventures_characterfaction_id_seq', 1, false);


--
-- Name: adventures_characterrelationship_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.adventures_characterrelationship_id_seq', 1, false);


--
-- Name: adventures_charactersystem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.adventures_charactersystem_id_seq', 47, true);


--
-- Name: adventures_charactertechnique_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.adventures_charactertechnique_id_seq', 70, true);


--
-- Name: adventures_faction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.adventures_faction_id_seq', 37, true);


--
-- Name: adventures_location_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.adventures_location_id_seq', 36, true);


--
-- Name: adventures_otherinfo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.adventures_otherinfo_id_seq', 1, false);


--
-- Name: adventures_race_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.adventures_race_id_seq', 108, true);


--
-- Name: adventures_skillsystem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.adventures_skillsystem_id_seq', 54, true);


--
-- Name: adventures_technique_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.adventures_technique_id_seq', 96, true);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 120, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 30, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 42, true);


--
-- Name: users_administrator_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.users_administrator_id_seq', 2, true);


--
-- Name: users_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.users_user_groups_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.users_user_id_seq', 3, true);


--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.users_user_user_permissions_id_seq', 1, false);


--
-- Name: adventures_adventure adventures_adventure_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_adventure
    ADD CONSTRAINT adventures_adventure_pkey PRIMARY KEY (id);


--
-- Name: adventures_adventureevent adventures_adventureevent_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_adventureevent
    ADD CONSTRAINT adventures_adventureevent_pkey PRIMARY KEY (id);


--
-- Name: adventures_adventureherosetup adventures_adventureherosetup_adventure_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_adventureherosetup
    ADD CONSTRAINT adventures_adventureherosetup_adventure_id_key UNIQUE (adventure_id);


--
-- Name: adventures_adventureherosetup adventures_adventureherosetup_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_adventureherosetup
    ADD CONSTRAINT adventures_adventureherosetup_pkey PRIMARY KEY (id);


--
-- Name: adventures_adventurehistory adventures_adventurehistory_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_adventurehistory
    ADD CONSTRAINT adventures_adventurehistory_pkey PRIMARY KEY (id);


--
-- Name: adventures_adventurememory adventures_adventurememory_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_adventurememory
    ADD CONSTRAINT adventures_adventurememory_pkey PRIMARY KEY (id);


--
-- Name: adventures_character adventures_character_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_character
    ADD CONSTRAINT adventures_character_pkey PRIMARY KEY (id);


--
-- Name: adventures_characterfaction adventures_characterfaction_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_characterfaction
    ADD CONSTRAINT adventures_characterfaction_pkey PRIMARY KEY (id);


--
-- Name: adventures_characterrelationship adventures_characterrelationship_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_characterrelationship
    ADD CONSTRAINT adventures_characterrelationship_pkey PRIMARY KEY (id);


--
-- Name: adventures_charactersystem adventures_charactersystem_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_charactersystem
    ADD CONSTRAINT adventures_charactersystem_pkey PRIMARY KEY (id);


--
-- Name: adventures_charactertechnique adventures_charactertechnique_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_charactertechnique
    ADD CONSTRAINT adventures_charactertechnique_pkey PRIMARY KEY (id);


--
-- Name: adventures_faction adventures_faction_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_faction
    ADD CONSTRAINT adventures_faction_pkey PRIMARY KEY (id);


--
-- Name: adventures_location adventures_location_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_location
    ADD CONSTRAINT adventures_location_pkey PRIMARY KEY (id);


--
-- Name: adventures_moderationentry adventures_moderationentry_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_moderationentry
    ADD CONSTRAINT adventures_moderationentry_pkey PRIMARY KEY (adventure_id);


--
-- Name: adventures_otherinfo adventures_otherinfo_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_otherinfo
    ADD CONSTRAINT adventures_otherinfo_pkey PRIMARY KEY (id);


--
-- Name: adventures_publishedadventure adventures_publishedadventure_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_publishedadventure
    ADD CONSTRAINT adventures_publishedadventure_pkey PRIMARY KEY (adventure_id);


--
-- Name: adventures_race adventures_race_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_race
    ADD CONSTRAINT adventures_race_pkey PRIMARY KEY (id);


--
-- Name: adventures_skillsystem adventures_skillsystem_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_skillsystem
    ADD CONSTRAINT adventures_skillsystem_pkey PRIMARY KEY (id);


--
-- Name: adventures_technique adventures_technique_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_technique
    ADD CONSTRAINT adventures_technique_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: authtoken_token authtoken_token_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_pkey PRIMARY KEY (key);


--
-- Name: authtoken_token authtoken_token_user_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_key UNIQUE (user_id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: adventures_charactersystem uq_character_system; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_charactersystem
    ADD CONSTRAINT uq_character_system UNIQUE (adventure_id, character_id, system_id);


--
-- Name: adventures_charactertechnique uq_character_technique; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_charactertechnique
    ADD CONSTRAINT uq_character_technique UNIQUE (adventure_id, character_id, technique_id);


--
-- Name: adventures_characterfaction uq_characters_factions; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_characterfaction
    ADD CONSTRAINT uq_characters_factions UNIQUE (adventure_id, character_id, faction_id);


--
-- Name: adventures_characterrelationship uq_relationship; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_characterrelationship
    ADD CONSTRAINT uq_relationship UNIQUE (adventure_id, from_character_id, to_character_id, kind);


--
-- Name: users_administrator users_administrator_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users_administrator
    ADD CONSTRAINT users_administrator_pkey PRIMARY KEY (id);


--
-- Name: users_administrator users_administrator_user_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users_administrator
    ADD CONSTRAINT users_administrator_user_id_key UNIQUE (user_id);


--
-- Name: users_user users_user_email_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_email_key UNIQUE (email);


--
-- Name: users_user_groups users_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_user_id_group_id_b88eab82_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_group_id_b88eab82_uniq UNIQUE (user_id, group_id);


--
-- Name: users_user users_user_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_permission_id_43338c45_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_permission_id_43338c45_uniq UNIQUE (user_id, permission_id);


--
-- Name: users_user users_user_username_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_username_key UNIQUE (username);


--
-- Name: adventures_adventure_author_user_id_fb7042ac; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_adventure_author_user_id_fb7042ac ON public.adventures_adventure USING btree (author_user_id);


--
-- Name: adventures_adventure_player_user_id_eefe2df4; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_adventure_player_user_id_eefe2df4 ON public.adventures_adventure USING btree (player_user_id);


--
-- Name: adventures_adventure_primary_hero_id_ed8161c1; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_adventure_primary_hero_id_ed8161c1 ON public.adventures_adventure USING btree (primary_hero_id);


--
-- Name: adventures_adventure_template_adventure_id_395afdb8; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_adventure_template_adventure_id_395afdb8 ON public.adventures_adventure USING btree (template_adventure_id);


--
-- Name: adventures_adventureevent_adventure_id_2c9e8aa4; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_adventureevent_adventure_id_2c9e8aa4 ON public.adventures_adventureevent USING btree (adventure_id);


--
-- Name: adventures_adventureevent_location_id_0ec44793; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_adventureevent_location_id_0ec44793 ON public.adventures_adventureevent USING btree (location_id);


--
-- Name: adventures_adventureherosetup_default_location_id_03ed22a2; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_adventureherosetup_default_location_id_03ed22a2 ON public.adventures_adventureherosetup USING btree (default_location_id);


--
-- Name: adventures_adventureherosetup_default_race_id_623daa87; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_adventureherosetup_default_race_id_623daa87 ON public.adventures_adventureherosetup USING btree (default_race_id);


--
-- Name: adventures_adventurehistory_adventure_id_51b38d0b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_adventurehistory_adventure_id_51b38d0b ON public.adventures_adventurehistory USING btree (adventure_id);


--
-- Name: adventures_adventurememory_adventure_id_83c93aff; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_adventurememory_adventure_id_83c93aff ON public.adventures_adventurememory USING btree (adventure_id);


--
-- Name: adventures_character_adventure_id_b35f85d9; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_character_adventure_id_b35f85d9 ON public.adventures_character USING btree (adventure_id);


--
-- Name: adventures_character_location_id_4813fe5d; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_character_location_id_4813fe5d ON public.adventures_character USING btree (location_id);


--
-- Name: adventures_character_race_id_952ac4ba; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_character_race_id_952ac4ba ON public.adventures_character USING btree (race_id);


--
-- Name: adventures_characterfaction_adventure_id_dc507002; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_characterfaction_adventure_id_dc507002 ON public.adventures_characterfaction USING btree (adventure_id);


--
-- Name: adventures_characterfaction_character_id_02fa92ed; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_characterfaction_character_id_02fa92ed ON public.adventures_characterfaction USING btree (character_id);


--
-- Name: adventures_characterfaction_faction_id_6ac35575; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_characterfaction_faction_id_6ac35575 ON public.adventures_characterfaction USING btree (faction_id);


--
-- Name: adventures_characterrelationship_adventure_id_1a75dfe7; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_characterrelationship_adventure_id_1a75dfe7 ON public.adventures_characterrelationship USING btree (adventure_id);


--
-- Name: adventures_characterrelationship_from_character_id_15ffa334; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_characterrelationship_from_character_id_15ffa334 ON public.adventures_characterrelationship USING btree (from_character_id);


--
-- Name: adventures_characterrelationship_to_character_id_2db22408; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_characterrelationship_to_character_id_2db22408 ON public.adventures_characterrelationship USING btree (to_character_id);


--
-- Name: adventures_charactersystem_adventure_id_306f307b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_charactersystem_adventure_id_306f307b ON public.adventures_charactersystem USING btree (adventure_id);


--
-- Name: adventures_charactersystem_character_id_903681e0; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_charactersystem_character_id_903681e0 ON public.adventures_charactersystem USING btree (character_id);


--
-- Name: adventures_charactersystem_system_id_3792f8f7; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_charactersystem_system_id_3792f8f7 ON public.adventures_charactersystem USING btree (system_id);


--
-- Name: adventures_charactertechnique_adventure_id_c08d1b7b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_charactertechnique_adventure_id_c08d1b7b ON public.adventures_charactertechnique USING btree (adventure_id);


--
-- Name: adventures_charactertechnique_character_id_00f23555; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_charactertechnique_character_id_00f23555 ON public.adventures_charactertechnique USING btree (character_id);


--
-- Name: adventures_charactertechnique_technique_id_5d2ea09b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_charactertechnique_technique_id_5d2ea09b ON public.adventures_charactertechnique USING btree (technique_id);


--
-- Name: adventures_faction_adventure_id_7c93dabf; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_faction_adventure_id_7c93dabf ON public.adventures_faction USING btree (adventure_id);


--
-- Name: adventures_location_adventure_id_769dd737; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_location_adventure_id_769dd737 ON public.adventures_location USING btree (adventure_id);


--
-- Name: adventures_otherinfo_adventure_id_19a4c3e0; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_otherinfo_adventure_id_19a4c3e0 ON public.adventures_otherinfo USING btree (adventure_id);


--
-- Name: adventures_race_adventure_id_abd1ab03; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_race_adventure_id_abd1ab03 ON public.adventures_race USING btree (adventure_id);


--
-- Name: adventures_skillsystem_adventure_id_1fa42538; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_skillsystem_adventure_id_1fa42538 ON public.adventures_skillsystem USING btree (adventure_id);


--
-- Name: adventures_technique_adventure_id_62626f30; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_technique_adventure_id_62626f30 ON public.adventures_technique USING btree (adventure_id);


--
-- Name: adventures_technique_system_id_71c51bd1; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX adventures_technique_system_id_71c51bd1 ON public.adventures_technique USING btree (system_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: authtoken_token_key_10f0b77e_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX authtoken_token_key_10f0b77e_like ON public.authtoken_token USING btree (key varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: idx_adventures_player; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_adventures_player ON public.adventures_adventure USING btree (player_user_id) WHERE (NOT is_template);


--
-- Name: idx_adventures_template; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_adventures_template ON public.adventures_adventure USING btree (is_template);


--
-- Name: idx_character_systems_adv; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_character_systems_adv ON public.adventures_charactersystem USING btree (adventure_id);


--
-- Name: idx_character_techniques_adv; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_character_techniques_adv ON public.adventures_charactertechnique USING btree (adventure_id);


--
-- Name: idx_characters_adv_location; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_characters_adv_location ON public.adventures_character USING btree (adventure_id, location_id);


--
-- Name: idx_characters_factions_adv; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_characters_factions_adv ON public.adventures_characterfaction USING btree (adventure_id);


--
-- Name: idx_characters_in_party; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_characters_in_party ON public.adventures_character USING btree (adventure_id, in_party);


--
-- Name: idx_characters_is_player; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_characters_is_player ON public.adventures_character USING btree (adventure_id, is_player);


--
-- Name: idx_characters_tags_gin; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_characters_tags_gin ON public.adventures_character USING gin (tags);


--
-- Name: idx_events_adv_loc_status; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_events_adv_loc_status ON public.adventures_adventureevent USING btree (adventure_id, location_id, status);


--
-- Name: idx_events_adv_status; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_events_adv_status ON public.adventures_adventureevent USING btree (adventure_id, status);


--
-- Name: idx_factions_tags_gin; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_factions_tags_gin ON public.adventures_faction USING gin (tags);


--
-- Name: idx_hero_setup_adv; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_hero_setup_adv ON public.adventures_adventureherosetup USING btree (adventure_id);


--
-- Name: idx_history_adv_entry_desc; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_history_adv_entry_desc ON public.adventures_adventurehistory USING btree (adventure_id, id DESC);


--
-- Name: idx_locations_adv_xy; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_locations_adv_xy ON public.adventures_location USING btree (adventure_id, x, y);


--
-- Name: idx_locations_tags_gin; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_locations_tags_gin ON public.adventures_location USING gin (tags);


--
-- Name: idx_memories_adv_importance; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_memories_adv_importance ON public.adventures_adventurememory USING btree (adventure_id, importance DESC);


--
-- Name: idx_memories_tags_gin; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_memories_tags_gin ON public.adventures_adventurememory USING gin (tags);


--
-- Name: idx_other_info_category; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_other_info_category ON public.adventures_otherinfo USING btree (adventure_id, category);


--
-- Name: idx_other_info_tags_gin; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_other_info_tags_gin ON public.adventures_otherinfo USING gin (tags);


--
-- Name: idx_races_tags_gin; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_races_tags_gin ON public.adventures_race USING gin (tags);


--
-- Name: idx_rel_from; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_rel_from ON public.adventures_characterrelationship USING btree (adventure_id, from_character_id);


--
-- Name: idx_rel_kind; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_rel_kind ON public.adventures_characterrelationship USING btree (adventure_id, kind);


--
-- Name: idx_rel_to; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_rel_to ON public.adventures_characterrelationship USING btree (adventure_id, to_character_id);


--
-- Name: idx_skill_systems_adv; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_skill_systems_adv ON public.adventures_skillsystem USING btree (adventure_id);


--
-- Name: idx_skill_systems_tags_gin; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_skill_systems_tags_gin ON public.adventures_skillsystem USING gin (tags);


--
-- Name: idx_techniques_adv_system; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_techniques_adv_system ON public.adventures_technique USING btree (adventure_id, system_id);


--
-- Name: idx_techniques_tags_gin; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_techniques_tags_gin ON public.adventures_technique USING gin (tags);


--
-- Name: users_user_email_243f6e77_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX users_user_email_243f6e77_like ON public.users_user USING btree (email varchar_pattern_ops);


--
-- Name: users_user_groups_group_id_9afc8d0e; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX users_user_groups_group_id_9afc8d0e ON public.users_user_groups USING btree (group_id);


--
-- Name: users_user_groups_user_id_5f6f5a90; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX users_user_groups_user_id_5f6f5a90 ON public.users_user_groups USING btree (user_id);


--
-- Name: users_user_user_permissions_permission_id_0b93982e; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX users_user_user_permissions_permission_id_0b93982e ON public.users_user_user_permissions USING btree (permission_id);


--
-- Name: users_user_user_permissions_user_id_20aca447; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX users_user_user_permissions_user_id_20aca447 ON public.users_user_user_permissions USING btree (user_id);


--
-- Name: users_user_username_06e46fe6_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX users_user_username_06e46fe6_like ON public.users_user USING btree (username varchar_pattern_ops);


--
-- Name: adventures_charactersystem trg_character_systems_same_adventure; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER trg_character_systems_same_adventure BEFORE INSERT OR UPDATE ON public.adventures_charactersystem FOR EACH ROW EXECUTE FUNCTION public.enforce_character_system_same_adventure();


--
-- Name: adventures_charactertechnique trg_character_techniques_same_adventure; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER trg_character_techniques_same_adventure BEFORE INSERT OR UPDATE ON public.adventures_charactertechnique FOR EACH ROW EXECUTE FUNCTION public.enforce_character_technique_same_adventure();


--
-- Name: adventures_characterfaction trg_characters_factions_same_adventure; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER trg_characters_factions_same_adventure BEFORE INSERT OR UPDATE ON public.adventures_characterfaction FOR EACH ROW EXECUTE FUNCTION public.enforce_character_faction_same_adventure();


--
-- Name: adventures_character trg_characters_same_adventure_refs; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER trg_characters_same_adventure_refs BEFORE INSERT OR UPDATE ON public.adventures_character FOR EACH ROW EXECUTE FUNCTION public.enforce_character_same_adventure_refs();


--
-- Name: adventures_characterrelationship trg_relationships_same_adventure; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER trg_relationships_same_adventure BEFORE INSERT OR UPDATE ON public.adventures_characterrelationship FOR EACH ROW EXECUTE FUNCTION public.enforce_relationship_same_adventure();


--
-- Name: adventures_technique trg_techniques_same_adventure_system; Type: TRIGGER; Schema: public; Owner: admin
--

CREATE TRIGGER trg_techniques_same_adventure_system BEFORE INSERT OR UPDATE ON public.adventures_technique FOR EACH ROW EXECUTE FUNCTION public.enforce_technique_same_adventure_as_system();


--
-- Name: adventures_adventureevent adventures_adventure_adventure_id_2c9e8aa4_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_adventureevent
    ADD CONSTRAINT adventures_adventure_adventure_id_2c9e8aa4_fk_adventure FOREIGN KEY (adventure_id) REFERENCES public.adventures_adventure(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_adventureherosetup adventures_adventure_adventure_id_2da372ec_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_adventureherosetup
    ADD CONSTRAINT adventures_adventure_adventure_id_2da372ec_fk_adventure FOREIGN KEY (adventure_id) REFERENCES public.adventures_adventure(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_adventurehistory adventures_adventure_adventure_id_51b38d0b_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_adventurehistory
    ADD CONSTRAINT adventures_adventure_adventure_id_51b38d0b_fk_adventure FOREIGN KEY (adventure_id) REFERENCES public.adventures_adventure(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_adventurememory adventures_adventure_adventure_id_83c93aff_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_adventurememory
    ADD CONSTRAINT adventures_adventure_adventure_id_83c93aff_fk_adventure FOREIGN KEY (adventure_id) REFERENCES public.adventures_adventure(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_adventure adventures_adventure_author_user_id_fb7042ac_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_adventure
    ADD CONSTRAINT adventures_adventure_author_user_id_fb7042ac_fk_users_user_id FOREIGN KEY (author_user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_adventureherosetup adventures_adventure_default_location_id_03ed22a2_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_adventureherosetup
    ADD CONSTRAINT adventures_adventure_default_location_id_03ed22a2_fk_adventure FOREIGN KEY (default_location_id) REFERENCES public.adventures_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_adventureherosetup adventures_adventure_default_race_id_623daa87_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_adventureherosetup
    ADD CONSTRAINT adventures_adventure_default_race_id_623daa87_fk_adventure FOREIGN KEY (default_race_id) REFERENCES public.adventures_race(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_adventureevent adventures_adventure_location_id_0ec44793_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_adventureevent
    ADD CONSTRAINT adventures_adventure_location_id_0ec44793_fk_adventure FOREIGN KEY (location_id) REFERENCES public.adventures_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_adventure adventures_adventure_player_user_id_eefe2df4_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_adventure
    ADD CONSTRAINT adventures_adventure_player_user_id_eefe2df4_fk_users_user_id FOREIGN KEY (player_user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_adventure adventures_adventure_primary_hero_id_ed8161c1_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_adventure
    ADD CONSTRAINT adventures_adventure_primary_hero_id_ed8161c1_fk_adventure FOREIGN KEY (primary_hero_id) REFERENCES public.adventures_character(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_adventure adventures_adventure_template_adventure_i_395afdb8_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_adventure
    ADD CONSTRAINT adventures_adventure_template_adventure_i_395afdb8_fk_adventure FOREIGN KEY (template_adventure_id) REFERENCES public.adventures_adventure(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_characterrelationship adventures_character_adventure_id_1a75dfe7_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_characterrelationship
    ADD CONSTRAINT adventures_character_adventure_id_1a75dfe7_fk_adventure FOREIGN KEY (adventure_id) REFERENCES public.adventures_adventure(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_charactersystem adventures_character_adventure_id_306f307b_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_charactersystem
    ADD CONSTRAINT adventures_character_adventure_id_306f307b_fk_adventure FOREIGN KEY (adventure_id) REFERENCES public.adventures_adventure(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_character adventures_character_adventure_id_b35f85d9_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_character
    ADD CONSTRAINT adventures_character_adventure_id_b35f85d9_fk_adventure FOREIGN KEY (adventure_id) REFERENCES public.adventures_adventure(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_charactertechnique adventures_character_adventure_id_c08d1b7b_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_charactertechnique
    ADD CONSTRAINT adventures_character_adventure_id_c08d1b7b_fk_adventure FOREIGN KEY (adventure_id) REFERENCES public.adventures_adventure(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_characterfaction adventures_character_adventure_id_dc507002_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_characterfaction
    ADD CONSTRAINT adventures_character_adventure_id_dc507002_fk_adventure FOREIGN KEY (adventure_id) REFERENCES public.adventures_adventure(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_charactertechnique adventures_character_character_id_00f23555_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_charactertechnique
    ADD CONSTRAINT adventures_character_character_id_00f23555_fk_adventure FOREIGN KEY (character_id) REFERENCES public.adventures_character(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_characterfaction adventures_character_character_id_02fa92ed_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_characterfaction
    ADD CONSTRAINT adventures_character_character_id_02fa92ed_fk_adventure FOREIGN KEY (character_id) REFERENCES public.adventures_character(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_charactersystem adventures_character_character_id_903681e0_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_charactersystem
    ADD CONSTRAINT adventures_character_character_id_903681e0_fk_adventure FOREIGN KEY (character_id) REFERENCES public.adventures_character(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_characterfaction adventures_character_faction_id_6ac35575_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_characterfaction
    ADD CONSTRAINT adventures_character_faction_id_6ac35575_fk_adventure FOREIGN KEY (faction_id) REFERENCES public.adventures_faction(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_characterrelationship adventures_character_from_character_id_15ffa334_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_characterrelationship
    ADD CONSTRAINT adventures_character_from_character_id_15ffa334_fk_adventure FOREIGN KEY (from_character_id) REFERENCES public.adventures_character(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_character adventures_character_location_id_4813fe5d_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_character
    ADD CONSTRAINT adventures_character_location_id_4813fe5d_fk_adventure FOREIGN KEY (location_id) REFERENCES public.adventures_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_character adventures_character_race_id_952ac4ba_fk_adventures_race_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_character
    ADD CONSTRAINT adventures_character_race_id_952ac4ba_fk_adventures_race_id FOREIGN KEY (race_id) REFERENCES public.adventures_race(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_charactersystem adventures_character_system_id_3792f8f7_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_charactersystem
    ADD CONSTRAINT adventures_character_system_id_3792f8f7_fk_adventure FOREIGN KEY (system_id) REFERENCES public.adventures_skillsystem(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_charactertechnique adventures_character_technique_id_5d2ea09b_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_charactertechnique
    ADD CONSTRAINT adventures_character_technique_id_5d2ea09b_fk_adventure FOREIGN KEY (technique_id) REFERENCES public.adventures_technique(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_characterrelationship adventures_character_to_character_id_2db22408_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_characterrelationship
    ADD CONSTRAINT adventures_character_to_character_id_2db22408_fk_adventure FOREIGN KEY (to_character_id) REFERENCES public.adventures_character(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_faction adventures_faction_adventure_id_7c93dabf_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_faction
    ADD CONSTRAINT adventures_faction_adventure_id_7c93dabf_fk_adventure FOREIGN KEY (adventure_id) REFERENCES public.adventures_adventure(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_location adventures_location_adventure_id_769dd737_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_location
    ADD CONSTRAINT adventures_location_adventure_id_769dd737_fk_adventure FOREIGN KEY (adventure_id) REFERENCES public.adventures_adventure(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_moderationentry adventures_moderatio_adventure_id_0d9a1072_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_moderationentry
    ADD CONSTRAINT adventures_moderatio_adventure_id_0d9a1072_fk_adventure FOREIGN KEY (adventure_id) REFERENCES public.adventures_adventure(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_otherinfo adventures_otherinfo_adventure_id_19a4c3e0_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_otherinfo
    ADD CONSTRAINT adventures_otherinfo_adventure_id_19a4c3e0_fk_adventure FOREIGN KEY (adventure_id) REFERENCES public.adventures_adventure(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_publishedadventure adventures_published_adventure_id_18941941_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_publishedadventure
    ADD CONSTRAINT adventures_published_adventure_id_18941941_fk_adventure FOREIGN KEY (adventure_id) REFERENCES public.adventures_adventure(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_race adventures_race_adventure_id_abd1ab03_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_race
    ADD CONSTRAINT adventures_race_adventure_id_abd1ab03_fk_adventure FOREIGN KEY (adventure_id) REFERENCES public.adventures_adventure(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_skillsystem adventures_skillsyst_adventure_id_1fa42538_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_skillsystem
    ADD CONSTRAINT adventures_skillsyst_adventure_id_1fa42538_fk_adventure FOREIGN KEY (adventure_id) REFERENCES public.adventures_adventure(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_technique adventures_technique_adventure_id_62626f30_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_technique
    ADD CONSTRAINT adventures_technique_adventure_id_62626f30_fk_adventure FOREIGN KEY (adventure_id) REFERENCES public.adventures_adventure(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: adventures_technique adventures_technique_system_id_71c51bd1_fk_adventure; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.adventures_technique
    ADD CONSTRAINT adventures_technique_system_id_71c51bd1_fk_adventure FOREIGN KEY (system_id) REFERENCES public.adventures_skillsystem(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authtoken_token authtoken_token_user_id_35299eff_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_35299eff_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_administrator users_administrator_user_id_b4ab1dd1_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users_administrator
    ADD CONSTRAINT users_administrator_user_id_b4ab1dd1_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_group_id_9afc8d0e_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_group_id_9afc8d0e_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_user_id_5f6f5a90_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_5f6f5a90_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_perm_permission_id_0b93982e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_perm_permission_id_0b93982e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_20aca447_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_20aca447_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

\unrestrict lsGxJN36EWHlpduPHO5dyUMwTdyV7p6rRHF2raAgtSripzI82TK2NwgIXdBacvR

